"""
eCourts Scraper - A Python tool to fetch court listings from eCourts India
"""

__version__ = "1.0.0"
__author__ = "eCourts Scraper Team"
