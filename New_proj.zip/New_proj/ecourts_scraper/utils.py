"""
Utility functions for eCourts scraper
"""

import re
import json
import logging
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any
from pathlib import Path


def setup_logging(level: str = "INFO") -> logging.Logger:
    """Setup logging configuration"""
    logging.basicConfig(
        level=getattr(logging, level.upper()),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(),
            logging.FileHandler('ecourts_scraper.log')
        ]
    )
    return logging.getLogger(__name__)


def validate_cnr(cnr: str) -> bool:
    """Validate CNR format"""
    if not cnr:
        return False
    
    # CNR format: Can be 16-20 digits or alphanumeric format like DLND030012342023
    # Pattern 1: Traditional 16-20 digits
    digit_pattern = r'^\d{16,20}$'
    # Pattern 2: Alphanumeric format (letters + digits, typically 16-20 characters)
    alphanumeric_pattern = r'^[A-Z0-9]{12,20}$'
    
    cnr_clean = cnr.strip().upper()
    return bool(re.match(digit_pattern, cnr_clean) or re.match(alphanumeric_pattern, cnr_clean))


def validate_case_input(case_type: str, case_number: str, year: str) -> bool:
    """Validate case input parameters"""
    if not all([case_type, case_number, year]):
        return False
    
    # Validate year (should be 4 digits, reasonable range)
    try:
        year_int = int(year)
        if year_int < 2000 or year_int > datetime.now().year + 1:
            return False
    except ValueError:
        return False
    
    return True


def parse_date(date_str: str) -> Optional[date]:
    """Parse various date formats"""
    date_formats = [
        '%d-%m-%Y',
        '%d/%m/%Y',
        '%Y-%m-%d',
        '%d-%m-%y',
        '%d/%m/%y'
    ]
    
    for fmt in date_formats:
        try:
            return datetime.strptime(date_str.strip(), fmt).date()
        except ValueError:
            continue
    
    return None


def get_date_range(target: str) -> tuple[date, date]:
    """Get date range for today or tomorrow"""
    today = date.today()
    
    if target.lower() == 'today':
        return today, today
    elif target.lower() == 'tomorrow':
        tomorrow = today + timedelta(days=1)
        return tomorrow, tomorrow
    elif target.lower() == 'both':
        tomorrow = today + timedelta(days=1)
        return today, tomorrow
    else:
        # Try to parse as date
        parsed_date = parse_date(target)
        if parsed_date:
            return parsed_date, parsed_date
        else:
            raise ValueError(f"Invalid date target: {target}")


def save_to_json(data: Dict[str, Any], filename: str) -> bool:
    """Save data to JSON file"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, default=str, ensure_ascii=False)
        return True
    except Exception as e:
        logging.error(f"Failed to save JSON file {filename}: {e}")
        return False


def save_to_text(data: Dict[str, Any], filename: str) -> bool:
    """Save data to text file"""
    try:
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(f"eCourts Scraper Results - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("=" * 60 + "\n\n")
            
            if 'case_info' in data:
                f.write("CASE INFORMATION:\n")
                f.write("-" * 20 + "\n")
                case_info = data['case_info']
                for key, value in case_info.items():
                    if value:
                        f.write(f"{key.replace('_', ' ').title()}: {value}\n")
                f.write("\n")
            
            if 'hearings' in data:
                f.write("HEARING INFORMATION:\n")
                f.write("-" * 20 + "\n")
                for hearing in data['hearings']:
                    f.write(f"Date: {hearing.get('hearing_date', 'N/A')}\n")
                    f.write(f"Serial Number: {hearing.get('serial_number', 'N/A')}\n")
                    f.write(f"Court: {hearing.get('court_name', 'N/A')}\n")
                    f.write(f"Case: {hearing.get('case_number', 'N/A')}\n")
                    f.write("-" * 40 + "\n")
        
        return True
    except Exception as e:
        logging.error(f"Failed to save text file {filename}: {e}")
        return False


def clean_text(text: str) -> str:
    """Clean and normalize text"""
    if not text:
        return ""
    
    # Remove extra whitespace and normalize
    text = re.sub(r'\s+', ' ', text.strip())
    # Remove special characters that might cause issues
    text = re.sub(r'[^\w\s\-.,()]', '', text)
    
    return text


def extract_case_number_from_text(text: str) -> Optional[str]:
    """Extract case number from text"""
    if not text:
        return None
    
    # Common case number patterns
    patterns = [
        r'Case\s+No[.:]?\s*([A-Z0-9/\-]+)',
        r'CNR\s*[.:]?\s*(\d{16,20})',
        r'(\d+/\d{4})',  # Simple number/year format
    ]
    
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    
    return None


def format_output(data: Dict[str, Any], format_type: str = "console") -> str:
    """Format output for different display types"""
    if format_type == "console":
        output = []
        output.append("=" * 60)
        output.append("eCourts Scraper Results")
        output.append("=" * 60)
        
        if 'case_info' in data:
            output.append("\nCASE INFORMATION:")
            output.append("-" * 20)
            for key, value in data['case_info'].items():
                if value:
                    output.append(f"{key.replace('_', ' ').title()}: {value}")
        
        if 'hearings' in data and data['hearings']:
            output.append("\nHEARING INFORMATION:")
            output.append("-" * 20)
            for hearing in data['hearings']:
                output.append(f"Date: {hearing.get('hearing_date', 'N/A')}")
                output.append(f"Serial Number: {hearing.get('serial_number', 'N/A')}")
                output.append(f"Court: {hearing.get('court_name', 'N/A')}")
                output.append(f"Case: {hearing.get('case_number', 'N/A')}")
                output.append("-" * 40)
        else:
            output.append("\nNo hearings found for the specified date(s).")
        
        output.append(f"\nGenerated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        output.append("=" * 60)
        
        return "\n".join(output)
    
    return str(data)


def create_output_filename(prefix: str, extension: str = "json") -> str:
    """Create timestamped output filename"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{prefix}_{timestamp}.{extension}"
