"""
Data models for eCourts scraper
"""

from datetime import datetime, date
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field


class CourtInfo(BaseModel):
    """Court information model"""
    state_code: str
    district_code: str
    court_code: str
    court_name: str
    court_type: str


class CaseInfo(BaseModel):
    """Case information model"""
    cnr: Optional[str] = None
    case_type: Optional[str] = None
    case_number: Optional[str] = None
    year: Optional[str] = None
    case_title: Optional[str] = None
    petitioner: Optional[str] = None
    respondent: Optional[str] = None
    filing_date: Optional[date] = None
    status: Optional[str] = None


class HearingInfo(BaseModel):
    """Hearing information model"""
    hearing_date: date
    serial_number: Optional[str] = None
    court_name: str
    bench_type: Optional[str] = None
    case_number: str
    case_title: Optional[str] = None
    petitioner: Optional[str] = None
    respondent: Optional[str] = None
    case_type: Optional[str] = None
    status: Optional[str] = None


class CauseList(BaseModel):
    """Cause list model"""
    court_name: str
    hearing_date: date
    total_cases: int
    hearings: List[HearingInfo]
    generated_at: datetime = Field(default_factory=datetime.now)


class ScrapingResult(BaseModel):
    """Result of scraping operation"""
    success: bool
    message: str
    data: Optional[Dict[str, Any]] = None
    error: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.now)
