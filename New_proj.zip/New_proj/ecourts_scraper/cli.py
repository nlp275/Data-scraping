"""
Command Line Interface for eCourts Scraper
"""

import click
import json
import sys
from datetime import datetime, date, timedelta
from typing import Optional
from pathlib import Path

from .scraper import ECourtsScraper
from .utils import (
    validate_cnr, validate_case_input, get_date_range, 
    save_to_json, save_to_text, format_output, create_output_filename
)


@click.group()
@click.version_option(version="1.0.0")
@click.option('--verbose', '-v', is_flag=True, help='Enable verbose logging')
@click.option('--output-dir', '-o', type=click.Path(), default='./output', 
              help='Output directory for saved files')
@click.pass_context
def cli(ctx, verbose, output_dir):
    """eCourts Scraper - Fetch court listings from eCourts India"""
    ctx.ensure_object(dict)
    ctx.obj['verbose'] = verbose
    ctx.obj['output_dir'] = Path(output_dir)
    ctx.obj['output_dir'].mkdir(exist_ok=True)


@cli.command()
@click.option('--cnr', help='Case Registration Number (CNR)')
@click.option('--case-type', help='Case Type (e.g., ABC, XYZ)')
@click.option('--case-number', help='Case Number')
@click.option('--year', help='Case Year')
@click.option('--state-code', default='', help='State Code')
@click.option('--district-code', default='', help='District Code')
@click.option('--court-code', default='', help='Court Code')
@click.option('--date', 'target_date', default='today', 
              help='Check for today, tomorrow, both, or specific date (DD-MM-YYYY)')
@click.option('--save-json', is_flag=True, help='Save results as JSON file')
@click.option('--save-text', is_flag=True, help='Save results as text file')
@click.option('--download-pdf', is_flag=True, help='Download case PDF if available')
@click.pass_context
def search(ctx, cnr, case_type, case_number, year, state_code, district_code, 
          court_code, target_date, save_json, save_text, download_pdf):
    """Search for a case and check if it's listed"""
    
    # Validate input
    if not cnr and not all([case_type, case_number, year]):
        click.echo("Error: Provide either CNR or Case Type, Number, and Year", err=True)
        sys.exit(1)
    
    if cnr and not validate_cnr(cnr):
        click.echo("Error: Invalid CNR format", err=True)
        sys.exit(1)
    
    if case_type and case_number and year:
        if not validate_case_input(case_type, case_number, year):
            click.echo("Error: Invalid case input parameters", err=True)
            sys.exit(1)
    
    # Initialize scraper
    scraper = ECourtsScraper()
    
    try:
        # Search for case
        if cnr:
            click.echo(f"Searching case by CNR: {cnr}")
            result = scraper.search_case_by_cnr(cnr)
        else:
            click.echo(f"Searching case: {case_type}/{case_number}/{year}")
            result = scraper.search_case_by_details(
                case_type, case_number, year, state_code, district_code, court_code
            )
        
        if not result.success:
            click.echo(f"Error: {result.message}", err=True)
            sys.exit(1)
        
        case_data = result.data
        
        # Get date range
        try:
            start_date, end_date = get_date_range(target_date)
            target_dates = [start_date]
            if start_date != end_date:
                current_date = start_date
                while current_date <= end_date:
                    target_dates.append(current_date)
                    current_date += timedelta(days=1)
        except ValueError as e:
            click.echo(f"Error: {e}", err=True)
            sys.exit(1)
        
        # Get hearings
        hearings = scraper.get_case_hearings(case_data, target_dates)
        
        # Prepare output data
        output_data = {
            'case_info': case_data,
            'hearings': [hearing.dict() for hearing in hearings],
            'search_date': datetime.now().isoformat(),
            'target_dates': [d.isoformat() for d in target_dates]
        }
        
        # Display results
        click.echo(format_output(output_data, "console"))
        
        # Save files if requested
        if save_json or save_text:
            base_filename = create_output_filename("case_search", "").rstrip('.')
            
            if save_json:
                json_filename = ctx.obj['output_dir'] / f"{base_filename}.json"
                if save_to_json(output_data, str(json_filename)):
                    click.echo(f"Results saved to: {json_filename}")
            
            if save_text:
                text_filename = ctx.obj['output_dir'] / f"{base_filename}.txt"
                if save_to_text(output_data, str(text_filename)):
                    click.echo(f"Results saved to: {text_filename}")
        
        # Download PDF if requested
        if download_pdf:
            base_filename = create_output_filename("case_search", "").rstrip('.')
            pdf_filename = ctx.obj['output_dir'] / f"{base_filename}.pdf"
            if scraper.download_case_pdf(case_data, str(pdf_filename)):
                click.echo(f"PDF downloaded to: {pdf_filename}")
            else:
                click.echo("No PDF available for this case")
        
        
        # Show summary
        if hearings:
            click.echo(f"\n✓ Found {len(hearings)} hearing(s) for the specified date(s)")
            for hearing in hearings:
                click.echo(f"  - {hearing.hearing_date}: Serial {hearing.serial_number} at {hearing.court_name}")
        else:
            click.echo(f"\n✗ No hearings found for the specified date(s)")
    
    except KeyboardInterrupt:
        click.echo("\nOperation cancelled by user", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Unexpected error: {e}", err=True)
        sys.exit(1)
    finally:
        scraper.close()


@cli.command()
@click.option('--court-code', required=True, help='Court Code')
@click.option('--date', 'hearing_date', default='today', 
              help='Date for cause list (today, tomorrow, or DD-MM-YYYY)')
@click.option('--save-json', is_flag=True, help='Save cause list as JSON file')
@click.option('--save-text', is_flag=True, help='Save cause list as text file')
@click.pass_context
def causelist(ctx, court_code, hearing_date, save_json, save_text):
    """Download entire cause list for a court and date"""
    
    # Parse date
    try:
        if hearing_date.lower() == 'today':
            target_date = date.today()
        elif hearing_date.lower() == 'tomorrow':
            target_date = date.today() + timedelta(days=1)
        else:
            from .utils import parse_date
            target_date = parse_date(hearing_date)
            if not target_date:
                click.echo("Error: Invalid date format. Use DD-MM-YYYY", err=True)
                sys.exit(1)
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        sys.exit(1)
    
    # Initialize scraper
    scraper = ECourtsScraper()
    
    try:
        click.echo(f"Fetching cause list for court {court_code} on {target_date}")
        
        cause_list = scraper.get_cause_list(court_code, target_date)
        
        if not cause_list:
            click.echo("No cause list found for the specified court and date")
            sys.exit(1)
        
        # Display summary
        click.echo(f"\nCause List Summary:")
        click.echo(f"Court: {cause_list.court_name}")
        click.echo(f"Date: {cause_list.hearing_date}")
        click.echo(f"Total Cases: {cause_list.total_cases}")
        click.echo(f"Generated: {cause_list.generated_at}")
        
        # Save files if requested
        if save_json or save_text:
            base_filename = create_output_filename("cause_list", "").rstrip('.')
            
            if save_json:
                json_filename = ctx.obj['output_dir'] / f"{base_filename}.json"
                cause_list_dict = cause_list.dict()
                if save_to_json(cause_list_dict, str(json_filename)):
                    click.echo(f"Cause list saved to: {json_filename}")
            
            if save_text:
                text_filename = ctx.obj['output_dir'] / f"{base_filename}.txt"
                cause_list_dict = cause_list.dict()
                if save_to_text(cause_list_dict, str(text_filename)):
                    click.echo(f"Cause list saved to: {text_filename}")
        
        # Show first few cases
        if cause_list.hearings:
            click.echo(f"\nFirst 10 cases:")
            for i, hearing in enumerate(cause_list.hearings[:10]):
                click.echo(f"{i+1:2d}. {hearing.serial_number} - {hearing.case_number} - {hearing.court_name}")
            
            if len(cause_list.hearings) > 10:
                click.echo(f"... and {len(cause_list.hearings) - 10} more cases")
    
    except KeyboardInterrupt:
        click.echo("\nOperation cancelled by user", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Unexpected error: {e}", err=True)
        sys.exit(1)
    finally:
        scraper.close()


@cli.command()
@click.option('--save-json', is_flag=True, help='Save court list as JSON file')
@click.pass_context
def courts(ctx, save_json):
    """List available courts"""
    
    # Initialize scraper
    scraper = ECourtsScraper()
    
    try:
        click.echo("Fetching available courts...")
        
        courts = scraper.get_court_list()
        
        if not courts:
            click.echo("No courts found")
            sys.exit(1)
        
        # Display courts
        click.echo(f"\nAvailable Courts ({len(courts)}):")
        click.echo("-" * 60)
        
        for court in courts:
            click.echo(f"Code: {court.court_code}")
            click.echo(f"Name: {court.court_name}")
            click.echo(f"Type: {court.court_type}")
            click.echo(f"State: {court.state_code}")
            click.echo(f"District: {court.district_code}")
            click.echo("-" * 60)
        
        # Save to file if requested
        if save_json:
            json_filename = ctx.obj['output_dir'] / "courts_list.json"
            courts_data = [court.dict() for court in courts]
            if save_to_json(courts_data, str(json_filename)):
                click.echo(f"Court list saved to: {json_filename}")
    
    except KeyboardInterrupt:
        click.echo("\nOperation cancelled by user", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Unexpected error: {e}", err=True)
        sys.exit(1)
    finally:
        scraper.close()


@cli.command()
@click.option('--host', default='127.0.0.1', help='Host to bind to')
@click.option('--port', default=5000, help='Port to bind to')
@click.option('--debug', is_flag=True, help='Enable debug mode')
def web(host, port, debug):
    """Start web API interface"""
    
    try:
        from .web_api import app
        click.echo(f"Starting web server on http://{host}:{port}")
        app.run(host=host, port=port, debug=debug)
    except ImportError:
        click.echo("Error: Flask not available. Install with: pip install flask", err=True)
        sys.exit(1)
    except Exception as e:
        click.echo(f"Error starting web server: {e}", err=True)
        sys.exit(1)


if __name__ == '__main__':
    cli()
