"""
Web API interface for eCourts Scraper
"""

from flask import Flask, request, jsonify, render_template_string
from datetime import datetime, date, timedelta
from typing import Dict, Any
import json

from .scraper import ECourtsScraper
from .utils import validate_cnr, validate_case_input, get_date_range


app = Flask(__name__)

# HTML template for the web interface
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>eCourts Scraper</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        .container {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        h1 {
            color: #333;
            text-align: center;
            margin-bottom: 30px;
        }
        .form-group {
            margin-bottom: 20px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        input, select, button {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
            margin-top: 10px;
        }
        button:hover {
            background-color: #0056b3;
        }
        .results {
            margin-top: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 4px;
            border-left: 4px solid #007bff;
        }
        .error {
            color: #dc3545;
            background-color: #f8d7da;
            border-left-color: #dc3545;
        }
        .success {
            color: #155724;
            background-color: #d4edda;
            border-left-color: #28a745;
        }
        .loading {
            color: #0c5460;
            background-color: #bee5eb;
            border-left-color: #17a2b8;
            text-align: center;
            font-weight: bold;
        }
        .tabs {
            display: flex;
            margin-bottom: 20px;
        }
        .tab {
            flex: 1;
            padding: 10px;
            text-align: center;
            background-color: #e9ecef;
            border: 1px solid #dee2e6;
            cursor: pointer;
        }
        .tab.active {
            background-color: #007bff;
            color: white;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .case-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .info-item {
            background: #f8f9fa;
            padding: 12px;
            border-radius: 6px;
            border-left: 4px solid #007bff;
        }
        .info-item.highlight {
            background: #e7f3ff;
            border-left-color: #28a745;
        }
        .case-history {
            margin-top: 15px;
        }
        .history-entry {
            display: flex;
            background: #f8f9fa;
            margin-bottom: 10px;
            border-radius: 6px;
            overflow: hidden;
        }
        .history-date {
            background: #007bff;
            color: white;
            padding: 12px;
            min-width: 120px;
            text-align: center;
            font-weight: bold;
        }
        .history-details {
            padding: 12px;
            flex: 1;
        }
        .hearing-item {
            display: flex;
            background: #e7f3ff;
            margin-bottom: 10px;
            border-radius: 6px;
            overflow: hidden;
            border-left: 4px solid #28a745;
        }
        .hearing-date {
            background: #28a745;
            color: white;
            padding: 12px;
            min-width: 120px;
            text-align: center;
            font-weight: bold;
        }
        .hearing-details {
            padding: 12px;
            flex: 1;
        }
        
        /* Hearing Status Header Styles */
        .hearing-status-header {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .hearing-status-header h2 {
            margin: 0 0 15px 0;
            font-size: 1.5em;
            text-align: center;
        }
        
        .hearing-summary {
            background: rgba(255,255,255,0.1);
            border-radius: 8px;
            padding: 15px;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .hearing-date-status {
            min-width: 120px;
            text-align: center;
        }
        
        .date-badge {
            display: inline-block;
            padding: 8px 16px;
            border-radius: 20px;
            font-weight: bold;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .date-badge.today {
            background: #dc3545;
            color: white;
            animation: pulse 2s infinite;
        }
        
        .date-badge.tomorrow {
            background: #ffc107;
            color: #212529;
        }
        
        .date-badge.other {
            background: #6c757d;
            color: white;
        }
        
        .hearing-details-summary {
            flex: 1;
            font-size: 1.1em;
            line-height: 1.6;
        }
        
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }
        
        /* PDF Download Styles */
        .pdf-download-section {
            background: #f8f9fa;
            border: 2px dashed #007bff;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
            text-align: center;
        }
        
        .pdf-download-btn {
            background: linear-gradient(135deg, #007bff, #0056b3);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(0,123,255,0.3);
        }
        
        .pdf-download-btn:hover {
            background: linear-gradient(135deg, #0056b3, #004085);
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(0,123,255,0.4);
        }
        
        .pdf-download-btn:active {
            transform: translateY(0);
        }
        
        .pdf-note {
            margin-top: 10px;
            color: #6c757d;
            font-size: 0.9em;
            font-style: italic;
        }
        
        /* Cause List Download Styles */
        .causelist-download-section {
            background: #f8f9fa;
            border: 2px dashed #28a745;
            border-radius: 10px;
            padding: 20px;
            margin-top: 20px;
            text-align: center;
        }
        
        .causelist-download-btn {
            background: linear-gradient(135deg, #28a745, #20c997);
            color: white;
            border: none;
            padding: 15px 30px;
            border-radius: 8px;
            font-size: 1.1em;
            font-weight: bold;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 6px rgba(40,167,69,0.3);
        }
        
        .causelist-download-btn:hover {
            background: linear-gradient(135deg, #20c997, #17a2b8);
            transform: translateY(-2px);
            box-shadow: 0 6px 12px rgba(40,167,69,0.4);
        }
        
        .causelist-download-btn:active {
            transform: translateY(0);
        }
        
        .causelist-note {
            margin-top: 10px;
            color: #6c757d;
            font-size: 0.9em;
            font-style: italic;
        }
        .case-info {
            background-color: #fff;
            padding: 15px;
            margin: 10px 0;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }
        .download-btn {
            background-color: #28a745;
            color: white;
            padding: 8px 16px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin: 5px;
        }
        .download-btn:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>🏛️ eCourts Scraper</h1>
        
        <div class="tabs">
            <div class="tab active" onclick="showTab('search')">Case Search</div>
            <div class="tab" onclick="showTab('causelist')">Cause List</div>
            <div class="tab" onclick="showTab('courts')">Courts</div>
        </div>

        <!-- Case Search Tab -->
        <div id="search" class="tab-content active">
            <form id="searchForm">
                <div class="form-group">
                    <label for="searchType">Search Type:</label>
                    <select id="searchType" onchange="toggleSearchType()">
                        <option value="cnr">By CNR</option>
                        <option value="details">By Case Details</option>
                    </select>
                </div>

                <div id="cnrFields">
                    <div class="form-group">
                        <label for="cnr">CNR (Case Registration Number):</label>
                        <input type="text" id="cnr" placeholder="Enter 16-20 digit CNR">
                    </div>
                </div>

                <div id="detailsFields" style="display: none;">
                    <div class="form-group">
                        <label for="caseType">Case Type:</label>
                        <input type="text" id="caseType" placeholder="e.g., ABC, XYZ">
                    </div>
                    <div class="form-group">
                        <label for="caseNumber">Case Number:</label>
                        <input type="text" id="caseNumber" placeholder="Case number">
                    </div>
                    <div class="form-group">
                        <label for="year">Year:</label>
                        <input type="text" id="year" placeholder="e.g., 2023">
                    </div>
                    <div class="form-group">
                        <label for="stateCode">State Code (Optional):</label>
                        <input type="text" id="stateCode" placeholder="State code">
                    </div>
                    <div class="form-group">
                        <label for="districtCode">District Code (Optional):</label>
                        <input type="text" id="districtCode" placeholder="District code">
                    </div>
                    <div class="form-group">
                        <label for="courtCode">Court Code (Optional):</label>
                        <input type="text" id="courtCode" placeholder="Court code">
                    </div>
                </div>

                <div class="form-group">
                    <label for="targetDate">Check for:</label>
                    <select id="targetDate">
                        <option value="today">Today</option>
                        <option value="tomorrow">Tomorrow</option>
                        <option value="both">Both Today & Tomorrow</option>
                    </select>
                </div>

                <button type="submit">Search Case</button>
            </form>

            <div id="searchResults"></div>
        </div>

        <!-- Cause List Tab -->
        <div id="causelist" class="tab-content">
            <form id="causelistForm">
                <div class="form-group">
                    <label for="courtCodeCl">Court Code:</label>
                    <input type="text" id="courtCodeCl" placeholder="Enter court code" required>
                </div>
                <div class="form-group">
                    <label for="hearingDate">Date:</label>
                    <select id="hearingDate">
                        <option value="today">Today</option>
                        <option value="tomorrow">Tomorrow</option>
                    </select>
                </div>
                <button type="submit">Get Cause List</button>
            </form>

            <div id="causelistResults"></div>
        </div>

        <!-- Courts Tab -->
        <div id="courts" class="tab-content">
            <button onclick="loadCourts()">Load Available Courts</button>
            <div id="courtsResults"></div>
        </div>
    </div>

    <script>
        // Script loaded
        
        // Global functions that need to be accessible from onclick handlers
        function showTab(tabName) {
            // Hide all tab contents
            const contents = document.querySelectorAll('.tab-content');
            contents.forEach(content => content.classList.remove('active'));
            
            // Remove active class from all tabs
            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(tab => tab.classList.remove('active'));
            
            // Show selected tab content
            document.getElementById(tabName).classList.add('active');
            
            // Add active class to clicked tab
            event.target.classList.add('active');
        }

        function toggleSearchType() {
            const searchType = document.getElementById('searchType').value;
            const cnrFields = document.getElementById('cnrFields');
            const detailsFields = document.getElementById('detailsFields');
            
            if (searchType === 'cnr') {
                cnrFields.style.display = 'block';
                detailsFields.style.display = 'none';
            } else {
                cnrFields.style.display = 'none';
                detailsFields.style.display = 'block';
            }
        }

        // Global function for loading courts
        async function loadCourts() {
            try {
                const response = await fetch('/api/courts');
                const data = await response.json();
                
                if (data.success) {
                    showCourtsResults(data);
                } else {
                    showError('courtsResults', data.message);
                }
            } catch (error) {
                showError('courtsResults', 'Error: ' + error.message);
            }
        }

        // Wait for DOM to be fully loaded before attaching event listeners
        document.addEventListener('DOMContentLoaded', function() {
            // DOM loaded, attaching event listeners
            
            // Test if we can find the form
            const form = document.getElementById('searchForm');
            // Form found
            
            if (form) {
                form.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                // Show loading state
                const resultsDiv = document.getElementById('searchResults');
                resultsDiv.innerHTML = '<div class="results loading">Searching... Please wait.</div>';
                
                const searchType = document.getElementById('searchType').value;
                const targetDate = document.getElementById('targetDate').value;
                
                let url = '/api/search?date=' + targetDate;
                
                if (searchType === 'cnr') {
                    const cnr = document.getElementById('cnr').value;
                    if (!cnr) {
                        showError('searchResults', 'Please enter a CNR');
                        return;
                    }
                    url += '&cnr=' + encodeURIComponent(cnr);
                } else {
                    const caseType = document.getElementById('caseType').value;
                    const caseNumber = document.getElementById('caseNumber').value;
                    const year = document.getElementById('year').value;
                    const stateCode = document.getElementById('stateCode').value;
                    const districtCode = document.getElementById('districtCode').value;
                    const courtCode = document.getElementById('courtCode').value;
                    
                    if (!caseType || !caseNumber || !year) {
                        showError('searchResults', 'Please enter Case Type, Number, and Year');
                        return;
                    }
                    
                    url += '&case_type=' + encodeURIComponent(caseType) +
                           '&case_number=' + encodeURIComponent(caseNumber) +
                           '&year=' + encodeURIComponent(year) +
                           '&state_code=' + encodeURIComponent(stateCode) +
                           '&district_code=' + encodeURIComponent(districtCode) +
                           '&court_code=' + encodeURIComponent(courtCode);
                }
                
                try {
                    console.log('Fetching URL:', url);
                    const response = await fetch(url);
                    console.log('Response status:', response.status);
                    
                    if (!response.ok) {
                        throw new Error(`HTTP error! status: ${response.status}`);
                    }
                    
                    const data = await response.json();
                    console.log('Response data:', data);
                    
                    if (data.success) {
                        showSearchResults(data);
                    } else {
                        console.error('API returned error:', data.message);
                        showError('searchResults', data.message);
                    }
                } catch (error) {
                    console.error('Fetch error:', error);
                    showError('searchResults', 'Error: ' + error.message);
                }
            });

            document.getElementById('causelistForm').addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const courtCode = document.getElementById('courtCodeCl').value;
                const hearingDate = document.getElementById('hearingDate').value;
                
                const url = '/api/causelist?court_code=' + encodeURIComponent(courtCode) + 
                           '&date=' + hearingDate;
                
                try {
                    const response = await fetch(url);
                    const data = await response.json();
                    
                    if (data.success) {
                        showError('causelistResults', 'Cause list functionality has been removed');
                    } else {
                        showError('causelistResults', data.message);
                    }
                } catch (error) {
                    showError('causelistResults', 'Error: ' + error.message);
                }
            });
        } else {
            console.error('Form not found!');
        }
        }); // End of DOMContentLoaded
        
        // Global functions that need to be accessible
        function showSearchResults(data) {
            console.log('showSearchResults called with data:', data);
            const resultsDiv = document.getElementById('searchResults');
            
            if (!resultsDiv) {
                console.error('Results div not found!');
                return;
            }
            
            if (!data || !data.data) {
                console.error('Invalid data structure:', data);
                showError('searchResults', 'Invalid response data');
                return;
            }
            
            let html = '<div class="results success">';
            
            // Show hearing status first - this is the most important information
            if (data.data.hearings && data.data.hearings.length > 0) {
                html += '<div class="hearing-status-header">';
                html += '<h2>🔔 Case Listed for Hearing</h2>';
                data.data.hearings.forEach(hearing => {
                    const hearingDate = new Date(hearing.hearing_date);
                    const today = new Date();
                    const tomorrow = new Date(today);
                    tomorrow.setDate(tomorrow.getDate() + 1);
                    
                    let dateStatus = '';
                    if (hearingDate.toDateString() === today.toDateString()) {
                        dateStatus = '<span class="date-badge today">TODAY</span>';
                    } else if (hearingDate.toDateString() === tomorrow.toDateString()) {
                        dateStatus = '<span class="date-badge tomorrow">TOMORROW</span>';
                    } else {
                        dateStatus = '<span class="date-badge other">' + hearingDate.toLocaleDateString() + '</span>';
                    }
                    
                    html += `<div class="hearing-summary">
                        <div class="hearing-date-status">${dateStatus}</div>
                        <div class="hearing-details-summary">
                            <strong>Serial Number:</strong> ${hearing.serial_number || 'N/A'}<br>
                            <strong>Court:</strong> ${hearing.court_name}<br>
                            <strong>Case:</strong> ${hearing.case_number}
                        </div>
                    </div>`;
                });
                html += '</div>';
            } else {
                html += '<div class="hearing-status-header">';
                html += '<h2>ℹ️ No Hearings Found</h2>';
                html += '<p>This case is not listed for hearing today or tomorrow.</p>';
                html += '</div>';
            }
            
            if (data.data.case_info) {
                const caseInfo = data.data.case_info;
                html += '<h3>📋 Case Information</h3>';
                html += '<div class="case-info-grid">';
                
                // Basic case details
                if (caseInfo.cnr) {
                    html += `<div class="info-item"><strong>CNR Number:</strong> ${caseInfo.cnr}</div>`;
                }
                if (caseInfo.case_type) {
                    html += `<div class="info-item"><strong>Case Type:</strong> ${caseInfo.case_type}</div>`;
                }
                if (caseInfo.filing_number) {
                    html += `<div class="info-item"><strong>Filing Number:</strong> ${caseInfo.filing_number}</div>`;
                }
                if (caseInfo.filing_date) {
                    html += `<div class="info-item"><strong>Filing Date:</strong> ${caseInfo.filing_date}</div>`;
                }
                if (caseInfo.registration_number) {
                    html += `<div class="info-item"><strong>Registration Number:</strong> ${caseInfo.registration_number}</div>`;
                }
                if (caseInfo.registration_date) {
                    html += `<div class="info-item"><strong>Registration Date:</strong> ${caseInfo.registration_date}</div>`;
                }
                
                // Hearing information
                if (caseInfo.first_hearing_date) {
                    html += `<div class="info-item"><strong>First Hearing:</strong> ${caseInfo.first_hearing_date}</div>`;
                }
                if (caseInfo.next_hearing_date) {
                    html += `<div class="info-item highlight"><strong>Next Hearing:</strong> ${caseInfo.next_hearing_date}</div>`;
                }
                if (caseInfo.case_stage) {
                    html += `<div class="info-item"><strong>Case Stage:</strong> ${caseInfo.case_stage}</div>`;
                }
                
                // Court information
                if (caseInfo.court_info) {
                    html += `<div class="info-item"><strong>Court:</strong> ${caseInfo.court_info}</div>`;
                }
                
                // Parties
                if (caseInfo.petitioner) {
                    html += `<div class="info-item"><strong>Petitioner:</strong> ${caseInfo.petitioner}</div>`;
                }
                if (caseInfo.respondent) {
                    html += `<div class="info-item"><strong>Respondent:</strong> ${caseInfo.respondent}</div>`;
                }
                
                // FIR details
                if (caseInfo.fir_number) {
                    html += `<div class="info-item"><strong>FIR Number:</strong> ${caseInfo.fir_number}</div>`;
                }
                if (caseInfo.fir_year) {
                    html += `<div class="info-item"><strong>FIR Year:</strong> ${caseInfo.fir_year}</div>`;
                }
                if (caseInfo.police_station) {
                    html += `<div class="info-item"><strong>Police Station:</strong> ${caseInfo.police_station}</div>`;
                }
                
                // Legal provisions
                if (caseInfo.acts) {
                    html += `<div class="info-item"><strong>Acts:</strong> ${caseInfo.acts}</div>`;
                }
                if (caseInfo.sections) {
                    html += `<div class="info-item"><strong>Sections:</strong> ${caseInfo.sections}</div>`;
                }
                
                html += '</div>';
                
                // Case history
                if (caseInfo.case_history && caseInfo.case_history.length > 0) {
                    html += '<h3>📅 Recent Case History</h3>';
                    html += '<div class="case-history">';
                    caseInfo.case_history.forEach(entry => {
                        html += `<div class="history-entry">
                            <div class="history-date">${entry.hearing_date}</div>
                            <div class="history-details">
                                <strong>Judge:</strong> ${entry.judge}<br>
                                <strong>Purpose:</strong> ${entry.purpose}
                            </div>
                        </div>`;
                    });
                    html += '</div>';
                }
                
                // PDF Download Button
                if (caseInfo.cnr) {
                    html += '<div class="pdf-download-section">';
                    html += '<h3>📄 Download Case Document</h3>';
                    html += `<button onclick="downloadCasePDF('${caseInfo.cnr}')" class="pdf-download-btn">
                        📥 Download Case PDF/Document
                    </button>`;
                    html += '<p class="pdf-note">Downloads the case document as PDF (if available) or comprehensive text document.</p>';
                    html += '</div>';
                }
                
                // Cause List Download Button
            }
            
            
            html += '</div>';
            resultsDiv.innerHTML = html;
        }


        function showCourtsResults(data) {
            const resultsDiv = document.getElementById('courtsResults');
            let html = '<div class="results success">';
            
            html += `<h3>Available Courts (${data.data.length}):</h3>`;
            
            data.data.forEach(court => {
                html += `<div class="case-info">
                    <strong>Code:</strong> ${court.court_code}<br>
                    <strong>Name:</strong> ${court.court_name}<br>
                    <strong>Type:</strong> ${court.court_type}<br>
                    <strong>State:</strong> ${court.state_code}<br>
                    <strong>District:</strong> ${court.district_code}
                </div>`;
            });
            
            html += '</div>';
            resultsDiv.innerHTML = html;
        }

        function showError(elementId, message) {
            const resultsDiv = document.getElementById(elementId);
            resultsDiv.innerHTML = `<div class="results error">Error: ${message}</div>`;
        }
        
        function downloadCasePDF(cnr) {
            try {
                // Show loading state
                const button = event.target;
                const originalText = button.innerHTML;
                button.innerHTML = '⏳ Downloading...';
                button.disabled = true;
                
                // Create download link
                const downloadUrl = `/api/download-pdf?cnr=${encodeURIComponent(cnr)}`;
                
                // Create a temporary link element and trigger download
                const link = document.createElement('a');
                link.href = downloadUrl;
                link.download = `case_${cnr}.pdf`;
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
                
                // Reset button after a delay
                setTimeout(() => {
                    button.innerHTML = originalText;
                    button.disabled = false;
                }, 2000);
                
            } catch (error) {
                console.error('Error downloading PDF:', error);
                alert('Error downloading PDF: ' + error.message);
                
                // Reset button
                const button = event.target;
                button.innerHTML = '📥 Download Case PDF/Document';
                button.disabled = false;
            }
        }
        
    </script>
</body>
</html>
"""


@app.route('/')
def index():
    """Serve the main web interface"""
    return render_template_string(HTML_TEMPLATE)


@app.route('/api/search')
def api_search():
    """API endpoint for case search"""
    try:
        # Get parameters
        cnr = request.args.get('cnr')
        case_type = request.args.get('case_type')
        case_number = request.args.get('case_number')
        year = request.args.get('year')
        state_code = request.args.get('state_code', '')
        district_code = request.args.get('district_code', '')
        court_code = request.args.get('court_code', '')
        target_date = request.args.get('date', 'today')
        
        # Validate input
        if not cnr and not all([case_type, case_number, year]):
            return jsonify({
                'success': False,
                'message': 'Provide either CNR or Case Type, Number, and Year'
            })
        
        if cnr and not validate_cnr(cnr):
            return jsonify({
                'success': False,
                'message': 'Invalid CNR format. CNR should be 12-20 characters (digits or alphanumeric)'
            })
        
        if case_type and case_number and year:
            if not validate_case_input(case_type, case_number, year):
                return jsonify({
                    'success': False,
                    'message': 'Invalid case input parameters'
                })
        
        # Initialize scraper
        scraper = ECourtsScraper()
        
        try:
            # Search for case
            if cnr:
                result = scraper.search_case_by_cnr(cnr)
            else:
                result = scraper.search_case_by_details(
                    case_type, case_number, year, state_code, district_code, court_code
                )
            
            if not result.success:
                return jsonify({
                    'success': False,
                    'message': result.message
                })
            
            case_data = result.data
            
            # Get date range
            start_date, end_date = get_date_range(target_date)
            target_dates = [start_date]
            if start_date != end_date:
                from datetime import timedelta
                current_date = start_date
                while current_date <= end_date:
                    target_dates.append(current_date)
                    current_date += timedelta(days=1)
            
            # Get hearings
            hearings = scraper.get_case_hearings(case_data, target_dates)
            
            # Prepare response data
            response_data = {
                'case_info': case_data,
                'hearings': [hearing.dict() for hearing in hearings],
                'search_date': datetime.now().isoformat(),
                'target_dates': [d.isoformat() for d in target_dates]
            }
            
            return jsonify({
                'success': True,
                'data': response_data
            })
            
        finally:
            scraper.close()
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        })


@app.route('/api/causelist')
def api_causelist():
    """API endpoint for cause list"""
    try:
        court_code = request.args.get('court_code')
        hearing_date = request.args.get('date', 'today')
        
        if not court_code:
            return jsonify({
                'success': False,
                'message': 'Court code is required'
            })
        
        # Parse date
        if hearing_date.lower() == 'today':
            target_date = date.today()
        elif hearing_date.lower() == 'tomorrow':
            target_date = date.today() + timedelta(days=1)
        else:
            from .utils import parse_date
            target_date = parse_date(hearing_date)
            if not target_date:
                return jsonify({
                    'success': False,
                    'message': 'Invalid date format'
                })
        
        # Initialize scraper
        scraper = ECourtsScraper()
        
        try:
            cause_list = scraper.get_cause_list(court_code, target_date)
            
            if not cause_list:
                return jsonify({
                    'success': False,
                    'message': 'No cause list found'
                })
            
            return jsonify({
                'success': True,
                'data': cause_list.dict()
            })
            
        finally:
            scraper.close()
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        })


@app.route('/api/download-pdf')
def api_download_pdf():
    """API endpoint for downloading case PDF"""
    try:
        cnr = request.args.get('cnr')
        
        if not cnr:
            return jsonify({
                'success': False,
                'message': 'CNR is required'
            })
        
        # Initialize scraper
        scraper = ECourtsScraper()
        
        try:
            # First, get the case data
            result = scraper.search_case_by_cnr(cnr)
            
            if not result or not result.success or not result.data:
                return jsonify({
                    'success': False,
                    'message': 'Case not found'
                })
            
            # Extract case data from the result
            case_data = result.data
            
            # Create a temporary filename
            import tempfile
            import os
            temp_dir = tempfile.gettempdir()
            pdf_filename = f"case_{cnr}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"
            pdf_path = os.path.join(temp_dir, pdf_filename)
            
            # Try to download PDF
            success = scraper.download_case_pdf(case_data, pdf_path)
            
            if success and os.path.exists(pdf_path):
                # Read the file and return it
                with open(pdf_path, 'rb') as f:
                    pdf_content = f.read()
                
                # Clean up temporary file
                os.remove(pdf_path)
                
                from flask import Response
                return Response(
                    pdf_content,
                    mimetype='application/pdf',
                    headers={
                        'Content-Disposition': f'attachment; filename=case_{cnr}.pdf',
                        'Content-Type': 'application/pdf'
                    }
                )
            else:
                return jsonify({
                    'success': False,
                    'message': 'PDF not available for this case'
                })
                
        finally:
            scraper.close()
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        })


@app.route('/api/courts')
def api_courts():
    """API endpoint for courts list"""
    try:
        # Initialize scraper
        scraper = ECourtsScraper()
        
        try:
            courts = scraper.get_court_list()
            
            return jsonify({
                'success': True,
                'data': [court.dict() for court in courts]
            })
            
        finally:
            scraper.close()
    
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Error: {str(e)}'
        })


if __name__ == '__main__':
    app.run(debug=True)
