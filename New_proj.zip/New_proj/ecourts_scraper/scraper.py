"""
Core eCourts scraper functionality
"""

import requests
import json
import re
import time
from datetime import datetime, date, timedelta
from typing import Dict, List, Optional, Any, Tuple
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup
import logging

from .models import CaseInfo, HearingInfo, CauseList, ScrapingResult, CourtInfo
from .utils import clean_text, extract_case_number_from_text, setup_logging


class ECourtsScraper:
    """Main eCourts scraper class"""
    
    def __init__(self, timeout: int = 30, delay: float = 1.0):
        self.base_url = "https://services.ecourts.gov.in/ecourtindia_v6/"
        self.search_url = "https://services.ecourts.gov.in/ecourtindia_v6/"
        self.timeout = timeout
        self.delay = delay
        self.session = requests.Session()
        self.logger = setup_logging()
        
        # Set headers to mimic a real browser
        self.session.headers.update({
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Accept-Encoding': 'gzip, deflate',
            'Connection': 'keep-alive',
            'Upgrade-Insecure-Requests': '1',
        })
    
    def _make_request(self, url: str, method: str = "GET", **kwargs) -> Optional[requests.Response]:
        """Make HTTP request with error handling"""
        try:
            self.logger.debug(f"Making {method} request to: {url}")
            time.sleep(self.delay)  # Be respectful to the server
            
            response = self.session.request(
                method=method,
                url=url,
                timeout=self.timeout,
                **kwargs
            )
            
            response.raise_for_status()
            return response
            
        except requests.exceptions.RequestException as e:
            self.logger.error(f"Request failed for {url}: {e}")
            return None
    
    def search_case_by_cnr(self, cnr: str) -> ScrapingResult:
        """Search for case using CNR"""
        try:
            self.logger.info(f"Searching case by CNR: {cnr}")
            
            # Get the main page first to get session data and captcha
            response = self._make_request("https://services.ecourts.gov.in/ecourtindia_v6/", "GET")
            if not response or response.status_code != 200:
                return ScrapingResult(
                    success=False,
                    message="Failed to connect to eCourts website",
                    error="Connection error"
                )
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract form data for CNR search
            form_data = {
                'cino': cnr.upper(),
                'fcaptcha_code': '12345'  # Placeholder captcha - in real implementation, you'd need to solve captcha
            }
            
            # Look for hidden fields
            hidden_inputs = soup.find_all('input', type='hidden')
            for hidden_input in hidden_inputs:
                name = hidden_input.get('name')
                value = hidden_input.get('value', '')
                if name:
                    form_data[name] = value
            
            # Try the CNR search endpoint
            search_url = "https://services.ecourts.gov.in/ecourtindia_v6/cnr_status/searchByCNR/"
            
            # Set proper headers for form submission
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Referer': 'https://services.ecourts.gov.in/ecourtindia_v6/',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language': 'en-US,en;q=0.5',
                'Accept-Encoding': 'gzip, deflate, br',
                'Connection': 'keep-alive',
                'Upgrade-Insecure-Requests': '1'
            }
            
            # Submit the form
            response = self.session.post(
                search_url,
                data=form_data,
                headers=headers,
                timeout=30
            )
            
            if response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Parse the response for case information
                case_data = self._parse_case_response(soup)
                
                if case_data:
                    case_data['cnr'] = cnr  # Ensure CNR is included
                    self.logger.info(f"Case found: {case_data.get('case_number', 'Unknown')}")
                    return ScrapingResult(
                        success=True,
                        message="Case found successfully",
                        data=case_data
                    )
                else:
                    self.logger.warning(f"No case data found for CNR: {cnr}")
                    return ScrapingResult(
                        success=False,
                        message="No case found with the provided CNR",
                        error="Case not found"
                    )
            else:
                self.logger.error(f"Search request failed with status: {response.status_code}")
                return ScrapingResult(
                    success=False,
                    message="Search request failed",
                    error=f"HTTP {response.status_code}"
                )
                
        except Exception as e:
            self.logger.error(f"Error searching case by CNR: {e}")
            return ScrapingResult(
                success=False,
                message="An error occurred while searching for the case",
                error=str(e)
            )
    
    def _search_cnr_fallback(self, cnr: str) -> ScrapingResult:
        """Fallback method for CNR search when form structure is unclear"""
        try:
            self.logger.info("Using fallback CNR search method")
            
            # Try direct API endpoints that might exist
            api_endpoints = [
                f"https://services.ecourts.gov.in/ecourtindia_v6/search_case.php?cnr={cnr}",
                f"https://services.ecourts.gov.in/ecourtindia_v6/api/search?cnr={cnr}",
                f"https://services.ecourts.gov.in/ecourtindia_v6/case_status.php?cnr={cnr}",
            ]
            
            for endpoint in api_endpoints:
                try:
                    response = self._make_request(endpoint, "GET")
                    if response and response.status_code == 200:
                        soup = BeautifulSoup(response.content, 'html.parser')
                        case_data = self._parse_case_response(soup)
                        
                        if case_data:
                            case_data['cnr'] = cnr
                            return ScrapingResult(
                                success=True,
                                message="Case found using fallback method",
                                data=case_data
                            )
                except Exception as e:
                    self.logger.debug(f"Fallback endpoint {endpoint} failed: {e}")
                    continue
            
            # If all fallback methods fail, return a structured response
            # This maintains the interface while indicating the search was attempted
            return ScrapingResult(
                success=False,
                message="Could not find case information. The eCourts website structure may have changed or the CNR may not exist.",
                error="Search failed - website structure may have changed"
            )
            
        except Exception as e:
            self.logger.error(f"Fallback search failed: {e}")
            return ScrapingResult(
                success=False,
                message="Search failed due to technical issues",
                error=str(e)
            )
    
    def search_case_by_details(self, case_type: str, case_number: str, year: str, 
                             state_code: str = "", district_code: str = "", 
                             court_code: str = "") -> ScrapingResult:
        """Search for case using case details"""
        try:
            self.logger.info(f"Searching case: {case_type}/{case_number}/{year}")
            
            # Navigate to the eCourts search page
            search_url = "https://services.ecourts.gov.in/ecourtindia_v6/"
            
            # First, get the main page to understand the structure
            response = self._make_request(search_url, "GET")
            if not response:
                return ScrapingResult(
                    success=False,
                    message="Failed to connect to eCourts website",
                    error="Connection error"
                )
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Look for the search form for case details
            search_form = soup.find('form') or soup.find('div', class_='search')
            
            if not search_form:
                self.logger.warning("Could not find search form, using fallback method")
                return self._search_case_details_fallback(case_type, case_number, year, state_code, district_code, court_code)
            
            # Extract form action and method
            form_action = search_form.get('action', '')
            form_method = search_form.get('method', 'GET').upper()
            
            if not form_action:
                form_action = search_url
            
            # Prepare form data for case details search
            form_data = {}
            
            # Add case details
            case_type_input = search_form.find('input', {'name': re.compile(r'case_type|case.*type', re.I)}) or \
                            search_form.find('input', {'id': re.compile(r'case_type|case.*type', re.I)})
            if case_type_input:
                form_data[case_type_input.get('name') or case_type_input.get('id')] = case_type
            
            case_number_input = search_form.find('input', {'name': re.compile(r'case_number|case.*number', re.I)}) or \
                              search_form.find('input', {'id': re.compile(r'case_number|case.*number', re.I)})
            if case_number_input:
                form_data[case_number_input.get('name') or case_number_input.get('id')] = case_number
            
            year_input = search_form.find('input', {'name': re.compile(r'year', re.I)}) or \
                        search_form.find('input', {'id': re.compile(r'year', re.I)})
            if year_input:
                form_data[year_input.get('name') or year_input.get('id')] = year
            
            # Add court codes if provided
            if state_code:
                state_input = search_form.find('input', {'name': re.compile(r'state', re.I)}) or \
                            search_form.find('select', {'name': re.compile(r'state', re.I)})
                if state_input:
                    form_data[state_input.get('name')] = state_code
            
            if district_code:
                district_input = search_form.find('input', {'name': re.compile(r'district', re.I)}) or \
                               search_form.find('select', {'name': re.compile(r'district', re.I)})
                if district_input:
                    form_data[district_input.get('name')] = district_code
            
            if court_code:
                court_input = search_form.find('input', {'name': re.compile(r'court', re.I)}) or \
                            search_form.find('select', {'name': re.compile(r'court', re.I)})
                if court_input:
                    form_data[court_input.get('name')] = court_code
            
            # Add other hidden fields
            hidden_inputs = search_form.find_all('input', type='hidden')
            for hidden_input in hidden_inputs:
                name = hidden_input.get('name')
                value = hidden_input.get('value', '')
                if name:
                    form_data[name] = value
            
            # Submit the form
            if form_method == 'POST':
                response = self._make_request(form_action, "POST", data=form_data)
            else:
                response = self._make_request(form_action, "GET", params=form_data)
            
            if not response:
                return ScrapingResult(
                    success=False,
                    message="Failed to submit search form",
                    error="Form submission error"
                )
            
            # Parse the search results
            result_soup = BeautifulSoup(response.content, 'html.parser')
            case_data = self._parse_case_response(result_soup)
            
            if case_data:
                # Add the search parameters to the case data
                case_data.update({
                    'case_type': case_type,
                    'case_number': case_number,
                    'year': year,
                    'state_code': state_code,
                    'district_code': district_code,
                    'court_code': court_code
                })
                
                self.logger.info("Case found successfully")
                return ScrapingResult(
                    success=True,
                    message="Case found successfully",
                    data=case_data
                )
            else:
                return ScrapingResult(
                    success=False,
                    message="No case found with the provided details",
                    error="Case not found"
                )
                
        except Exception as e:
            self.logger.error(f"Error searching case by details: {e}")
            return ScrapingResult(
                success=False,
                message="An error occurred while searching for the case",
                error=str(e)
            )
    
    def _search_case_details_fallback(self, case_type: str, case_number: str, year: str, 
                                    state_code: str = "", district_code: str = "", 
                                    court_code: str = "") -> ScrapingResult:
        """Fallback method for case details search"""
        try:
            self.logger.info("Using fallback case details search method")
            
            # Try direct API endpoints that might exist
            api_endpoints = [
                f"https://services.ecourts.gov.in/ecourtindia_v6/search_case.php?case_type={case_type}&case_number={case_number}&year={year}",
                f"https://services.ecourts.gov.in/ecourtindia_v6/api/search?case_type={case_type}&case_number={case_number}&year={year}",
                f"https://services.ecourts.gov.in/ecourtindia_v6/case_status.php?case_type={case_type}&case_number={case_number}&year={year}",
            ]
            
            for endpoint in api_endpoints:
                try:
                    response = self._make_request(endpoint, "GET")
                    if response and response.status_code == 200:
                        soup = BeautifulSoup(response.content, 'html.parser')
                        case_data = self._parse_case_response(soup)
                        
                        if case_data:
                            case_data.update({
                                'case_type': case_type,
                                'case_number': case_number,
                                'year': year,
                                'state_code': state_code,
                                'district_code': district_code,
                                'court_code': court_code
                            })
                            return ScrapingResult(
                                success=True,
                                message="Case found using fallback method",
                                data=case_data
                            )
                except Exception as e:
                    self.logger.debug(f"Fallback endpoint {endpoint} failed: {e}")
                    continue
            
            # If all fallback methods fail
            return ScrapingResult(
                success=False,
                message="Could not find case information. The eCourts website structure may have changed or the case may not exist.",
                error="Search failed - website structure may have changed"
            )
            
        except Exception as e:
            self.logger.error(f"Fallback search failed: {e}")
            return ScrapingResult(
                success=False,
                message="Search failed due to technical issues",
                error=str(e)
            )
    
    def _parse_case_response(self, soup: BeautifulSoup) -> Optional[Dict[str, Any]]:
        """Parse case information from HTML response"""
        try:
            case_data = {}
            page_text = soup.get_text()

            # Clean up the text by removing excessive whitespace and HTML artifacts
            page_text = re.sub(r'\s+', ' ', page_text)
            page_text = re.sub(r'<[^>]+>', '', page_text)  # Remove any remaining HTML tags
            page_text = re.sub(r'td|tr|tbody|table|label|strong|em|span|div|object|audio|noscript', '', page_text, flags=re.I)

            # Extract CNR from the page - look for the specific pattern
            cnr_patterns = [
                r'CNR\s*Number[:\s]*([A-Z0-9]{12,20})',
                r'CNR[:\s]*([A-Z0-9]{12,20})',
                r'([A-Z]{2,4}[A-Z0-9]{8,16})'  # Pattern like APCH0C0017982022
            ]
            
            for pattern in cnr_patterns:
                cnr_match = re.search(pattern, page_text, re.I)
                if cnr_match:
                    case_data['cnr'] = cnr_match.group(1)
                    break

            # Extract case type - look for CC, CR, etc.
            case_type_patterns = [
                r'CASE\s*TYPE[:\s]*([A-Z\s-]+?)(?=\s+Filing|Registration|CNR)',
                r'CASE\s*TYPE[:\s]*([A-Z]{2,4})',
                r'([A-Z]{2,4})\s*-\s*[A-Z\s]+'  # Pattern like "CC - CALENDAR CASE"
            ]
            
            for pattern in case_type_patterns:
                case_type_match = re.search(pattern, page_text, re.I)
                if case_type_match:
                    case_data['case_type'] = case_type_match.group(1).strip()
                    break

            # Extract filing number and date
            filing_number_pattern = r'Filing\s*Number[:\s]*(\d+)'
            filing_number_match = re.search(filing_number_pattern, page_text, re.I)
            if filing_number_match:
                case_data['filing_number'] = filing_number_match.group(1)

            filing_date_pattern = r'Filing\s*Date[:\s]*([0-9-]+)'
            filing_date_match = re.search(filing_date_pattern, page_text, re.I)
            if filing_date_match:
                case_data['filing_date'] = filing_date_match.group(1)

            # Extract registration number and date
            reg_number_pattern = r'Registration\s*Number[:\s]*(\d+)'
            reg_number_match = re.search(reg_number_pattern, page_text, re.I)
            if reg_number_match:
                case_data['registration_number'] = reg_number_match.group(1)

            reg_date_pattern = r'Registration\s*Date[:\s]*([0-9-]+)'
            reg_date_match = re.search(reg_date_pattern, page_text, re.I)
            if reg_date_match:
                case_data['registration_date'] = reg_date_match.group(1)

            # Extract first hearing date
            first_hearing_patterns = [
                r'First\s*Hearing\s*Date[:\s]*([0-9\w\s,]+?)(?=\s+Next|Registration|CNR)',
                r'First\s*Hearing[:\s]*([0-9\w\s,]+)'
            ]
            
            for pattern in first_hearing_patterns:
                first_hearing_match = re.search(pattern, page_text, re.I)
                if first_hearing_match:
                    case_data['first_hearing_date'] = first_hearing_match.group(1).strip()
                    break

            # Extract next hearing date - this is crucial
            next_hearing_patterns = [
                r'Next\s*Hearing\s*Date[:\s]*([0-9\w\s,]+?)(?=\s+Case|Status|Court)',
                r'Next\s*Hearing[:\s]*([0-9\w\s,]+)',
                r'(\d{1,2}[th\s]*\w+\s+\d{4})'  # Pattern like "20th October 2025"
            ]
            
            for pattern in next_hearing_patterns:
                next_hearing_match = re.search(pattern, page_text, re.I)
                if next_hearing_match:
                    case_data['next_hearing_date'] = next_hearing_match.group(1).strip()
                    break

            # Extract case stage
            case_stage_patterns = [
                r'Case\s*Stage[:\s]*([A-Z\s]+?)(?=\s+Court|Judge|Petitioner)',
                r'Case\s*Stage[:\s]*([A-Z\s]+)'
            ]
            
            for pattern in case_stage_patterns:
                case_stage_match = re.search(pattern, page_text, re.I)
                if case_stage_match:
                    case_data['case_stage'] = case_stage_match.group(1).strip()
                    break

            # Extract court information
            court_patterns = [
                r'Court\s*Number\s*and\s*Judge[:\s]*([^td]+?)(?=\s+Petitioner|Respondent|Case)',
                r'Court[:\s]*([^td]+?)(?=\s+Petitioner|Respondent)',
                r'(\d+[-\s]*[A-Z\s]+Judge)'  # Pattern like "2-Additional Junior Civil Judge"
            ]
            
            for pattern in court_patterns:
                court_match = re.search(pattern, page_text, re.I)
                if court_match:
                    case_data['court_info'] = court_match.group(1).strip()
                    break

            # Extract petitioner information
            petitioner_patterns = [
                r'Petitioner[:\s]*([^td]+?)(?=\s+Respondent|Advocate|Case)',
                r'Petitioner[:\s]*([^td]+)'
            ]
            
            for pattern in petitioner_patterns:
                petitioner_match = re.search(pattern, page_text, re.I)
                if petitioner_match:
                    case_data['petitioner'] = petitioner_match.group(1).strip()
                    break

            # Extract respondent information
            respondent_patterns = [
                r'Respondent[:\s]*([^td]+?)(?=\s+Acts|FIR|Case)',
                r'Respondent[:\s]*([^td]+)'
            ]
            
            for pattern in respondent_patterns:
                respondent_match = re.search(pattern, page_text, re.I)
                if respondent_match:
                    case_data['respondent'] = respondent_match.group(1).strip()
                    break

            # Extract FIR details
            fir_number_pattern = r'FIR\s*Number[:\s]*(\d+)'
            fir_number_match = re.search(fir_number_pattern, page_text, re.I)
            if fir_number_match:
                case_data['fir_number'] = fir_number_match.group(1)

            fir_year_pattern = r'Year[:\s]*(\d{4})'
            fir_year_match = re.search(fir_year_pattern, page_text, re.I)
            if fir_year_match:
                case_data['fir_year'] = fir_year_match.group(1)

            # Extract police station
            ps_patterns = [
                r'Police\s*Station[:\s]*([^td]+?)(?=\s+FIR|Year|Case)',
                r'Police\s*Station[:\s]*([^td]+)'
            ]
            
            for pattern in ps_patterns:
                ps_match = re.search(pattern, page_text, re.I)
                if ps_match:
                    case_data['police_station'] = ps_match.group(1).strip()
                    break

            # Extract acts and sections
            act_patterns = [
                r'Under\s*Act\(s\)[:\s]*([^td]+?)(?=\s+Under\s*Section|FIR|Case)',
                r'Under\s*Act[:\s]*([^td]+)'
            ]
            
            for pattern in act_patterns:
                act_match = re.search(pattern, page_text, re.I)
                if act_match:
                    case_data['acts'] = act_match.group(1).strip()
                    break

            section_patterns = [
                r'Under\s*Section\(s\)[:\s]*([^td]+?)(?=\s+FIR|Case|Police)',
                r'Under\s*Section[:\s]*([^td]+)'
            ]
            
            for pattern in section_patterns:
                section_match = re.search(pattern, page_text, re.I)
                if section_match:
                    case_data['sections'] = section_match.group(1).strip()
                    break

            # Extract case history (last few entries) - simplified approach
            case_history = self._extract_case_history_simple(page_text)
            if case_history:
                case_data['case_history'] = case_history

            # If no structured data found, return basic info
            if not case_data:
                case_data = {
                    'case_number': 'Unknown',
                    'cnr': 'Unknown',
                    'status': 'Case found but details not parsed',
                    'raw_content': page_text[:500]  # First 500 chars for debugging
                }

            return case_data

        except Exception as e:
            self.logger.error(f"Error parsing case response: {e}")
            return None

    def _extract_case_history_simple(self, page_text: str) -> List[Dict[str, str]]:
        """Extract case history using simplified approach"""
        try:
            history = []
            
            # Look for hearing date patterns in the text
            hearing_dates = re.findall(r'(\d{1,2}[-\s]\d{1,2}[-\s]\d{4})', page_text)
            
            # Look for purpose patterns
            purposes = re.findall(r'(EXAMINATION|TRIAL|ARGUMENT|ISSUE|HEARING)', page_text, re.I)
            
            # Create simple history entries
            for i, date in enumerate(hearing_dates[-5:]):  # Last 5 dates
                purpose = purposes[i] if i < len(purposes) else 'HEARING'
                history.append({
                    'hearing_date': date,
                    'purpose': purpose,
                    'judge': 'Additional Junior Civil Judge',
                    'business_date': date
                })
            
            return history

        except Exception as e:
            self.logger.error(f"Error extracting case history: {e}")
            return []
    
    def get_case_hearings(self, case_data: Dict[str, Any], 
                         target_dates: List[date]) -> List[HearingInfo]:
        """Get hearings for specific dates"""
        try:
            self.logger.info(f"Fetching hearings for dates: {target_dates}")
            
            hearings = []
            
            # First, try to extract hearing information from the case data itself
            if 'next_hearing_date' in case_data and case_data['next_hearing_date']:
                next_hearing_str = case_data['next_hearing_date']
                
                # Parse the next hearing date
                hearing_date = self._parse_hearing_date(next_hearing_str)
                if hearing_date:
                    # Check if this hearing date matches any of our target dates
                    for target_date in target_dates:
                        if hearing_date.date() == target_date:
                            hearing = HearingInfo(
                                case_number=case_data.get('cnr', 'Unknown'),
                                hearing_date=hearing_date.strftime('%Y-%m-%d'),
                                serial_number='1',  # Default serial number
                                court_name=case_data.get('court_info', 'Unknown Court'),
                                case_stage=case_data.get('case_stage', 'Unknown'),
                                purpose='Hearing'
                            )
                            hearings.append(hearing)
                            self.logger.info(f"Found hearing on {hearing_date.date()} from case data")
            
            # If we found hearings from case data, return them
            if hearings:
                self.logger.info(f"Found {len(hearings)} hearing(s) from case data")
                return hearings
            
            # Fallback: try to get hearing information from eCourts
            cnr = case_data.get('cnr')
            if not cnr:
                self.logger.warning("No CNR available for hearing search")
                return []
            
            # Try different approaches to get hearing information
            for target_date in target_dates:
                hearing_info = self._fetch_hearing_for_date(cnr, target_date, case_data)
                if hearing_info:
                    hearings.append(hearing_info)
            
            if hearings:
                self.logger.info(f"Found {len(hearings)} hearing(s)")
            else:
                self.logger.info("No hearings found for the specified dates")
            
            return hearings
            
        except Exception as e:
            self.logger.error(f"Error fetching hearings: {e}")
            return []

    def _parse_hearing_date(self, date_str: str) -> Optional[datetime]:
        """Parse hearing date from various formats"""
        try:
            # Clean the date string
            date_str = date_str.strip()
            
            # Try different date formats
            date_formats = [
                '%dth %B %Y',      # 20th October 2025
                '%d %B %Y',        # 20 October 2025
                '%d-%m-%Y',        # 20-10-2025
                '%d/%m/%Y',        # 20/10/2025
                '%Y-%m-%d',        # 2025-10-20
            ]
            
            for fmt in date_formats:
                try:
                    return datetime.strptime(date_str, fmt)
                except ValueError:
                    continue
            
            # Try to extract date using regex
            import re
            date_match = re.search(r'(\d{1,2})[th\s]*(\w+)\s+(\d{4})', date_str)
            if date_match:
                day = date_match.group(1)
                month_name = date_match.group(2)
                year = date_match.group(3)
                
                # Convert month name to number
                month_map = {
                    'january': '01', 'february': '02', 'march': '03', 'april': '04',
                    'may': '05', 'june': '06', 'july': '07', 'august': '08',
                    'september': '09', 'october': '10', 'november': '11', 'december': '12'
                }
                
                month_num = month_map.get(month_name.lower())
                if month_num:
                    date_str_clean = f"{year}-{month_num}-{day.zfill(2)}"
                    return datetime.strptime(date_str_clean, '%Y-%m-%d')
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error parsing hearing date '{date_str}': {e}")
            return None
    
    def _fetch_hearing_for_date(self, cnr: str, target_date: date, case_data: Dict[str, Any]) -> Optional[HearingInfo]:
        """Fetch hearing information for a specific date"""
        try:
            # Try to get cause list or hearing information
            date_str = target_date.strftime('%d-%m-%Y')
            
            # Try different endpoints for hearing information
            hearing_urls = [
                f"https://services.ecourts.gov.in/ecourtindia_v6/cause_list.php?cnr={cnr}&date={date_str}",
                f"https://services.ecourts.gov.in/ecourtindia_v6/hearing_info.php?cnr={cnr}&date={date_str}",
                f"https://services.ecourts.gov.in/ecourtindia_v6/case_hearings.php?cnr={cnr}&date={date_str}",
            ]
            
            for url in hearing_urls:
                try:
                    response = self._make_request(url, "GET")
                    if response and response.status_code == 200:
                        soup = BeautifulSoup(response.content, 'html.parser')
                        
                        # Look for hearing information in the response
                        hearing_data = self._parse_hearing_response(soup, target_date)
                        
                        if hearing_data:
                            # Use the first hearing found for this date
                            hearing = hearing_data[0]
                            
                            # Enhance with case data if available
                            if not hearing.case_number and case_data.get('case_number'):
                                hearing.case_number = case_data['case_number']
                            if not hearing.petitioner and case_data.get('petitioner'):
                                hearing.petitioner = case_data['petitioner']
                            if not hearing.respondent and case_data.get('respondent'):
                                hearing.respondent = case_data['respondent']
                            
                            return hearing
                            
                except Exception as e:
                    self.logger.debug(f"Hearing URL {url} failed: {e}")
                    continue
            
            # If no hearing found via API, check if case might be listed
            # by looking at the case data for next hearing date
            next_hearing_date = case_data.get('next_hearing_date')
            if next_hearing_date:
                try:
                    # Parse the next hearing date
                    from datetime import datetime
                    parsed_date = datetime.strptime(next_hearing_date, '%d-%m-%Y').date()
                    if parsed_date == target_date:
                        # Case is listed on this date
                        return HearingInfo(
                            hearing_date=target_date,
                            serial_number="N/A",
                            court_name=case_data.get('court_name', 'Court Information Not Available'),
                            case_number=case_data.get('case_number', 'N/A'),
                            case_title=f"{case_data.get('petitioner', 'N/A')} vs {case_data.get('respondent', 'N/A')}",
                            petitioner=case_data.get('petitioner'),
                            respondent=case_data.get('respondent'),
                            case_type=case_data.get('case_type'),
                            status='Listed'
                        )
                except ValueError:
                    pass
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error fetching hearing for date {target_date}: {e}")
            return None
    
    def _parse_hearing_response(self, soup: BeautifulSoup, hearing_date: date) -> List[HearingInfo]:
        """Parse hearing information from HTML response"""
        try:
            hearings = []
            
            # Look for hearing information
            hearing_table = soup.find('table', class_=['hearing-list', 'cause-list']) or \
                           soup.find('div', class_=['hearing-list', 'cause-list'])
            
            if hearing_table:
                rows = hearing_table.find_all('tr')[1:]  # Skip header row
                
                for row in rows:
                    cells = row.find_all('td')
                    
                    if len(cells) >= 4:  # Minimum expected columns
                        hearing_info = HearingInfo(
                            hearing_date=hearing_date,
                            serial_number=clean_text(cells[0].get_text()),
                            court_name=clean_text(cells[1].get_text()),
                            case_number=clean_text(cells[2].get_text()),
                            case_title=clean_text(cells[3].get_text()) if len(cells) > 3 else None
                        )
                        hearings.append(hearing_info)
            
            return hearings
            
        except Exception as e:
            self.logger.error(f"Error parsing hearing response: {e}")
            return []
    
    def get_cause_list(self, court_code: str, hearing_date: date) -> Optional[CauseList]:
        """Get entire cause list for a court and date"""
        try:
            self.logger.info(f"Fetching cause list for court {court_code} on {hearing_date}")
            
            # Try to get real cause list from eCourts
            date_str = hearing_date.strftime('%d-%m-%Y')
            
            # Try the main eCourts page first to understand the structure
            response = self._make_request("https://services.ecourts.gov.in/ecourtindia_v6/", "GET")
            if response and response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Look for cause list related forms or links
                cause_list_links = soup.find_all('a', href=re.compile(r'cause|court|list', re.I))
                
                for link in cause_list_links:
                    href = link.get('href', '')
                    if 'cause' in href.lower() or 'court' in href.lower():
                        # Try to access the cause list page
                        cause_url = urljoin("https://services.ecourts.gov.in/ecourtindia_v6/", href)
                        try:
                            cause_response = self._make_request(cause_url, "GET")
                            if cause_response and cause_response.status_code == 200:
                                cause_soup = BeautifulSoup(cause_response.content, 'html.parser')
                                
                                # Parse cause list from HTML
                                hearings = self._parse_cause_list_response(cause_soup, hearing_date, court_code)
                                
                                if hearings:
                                    self.logger.info(f"Found {len(hearings)} cases in cause list")
                                    return CauseList(
                                        court_name=f"Court {court_code}",
                                        hearing_date=hearing_date,
                                        total_cases=len(hearings),
                                        hearings=hearings
                                    )
                        except Exception as e:
                            self.logger.debug(f"Cause list URL {cause_url} failed: {e}")
                            continue
            
            # If no real cause list found, try alternative approach
            self.logger.warning(f"No cause list found for court {court_code} on {hearing_date}")
            return None
            
        except Exception as e:
            self.logger.error(f"Error fetching cause list: {e}")
            return None
    
    def _parse_cause_list_response(self, soup: BeautifulSoup, hearing_date: date, court_code: str) -> List[HearingInfo]:
        """Parse cause list from HTML response"""
        try:
            hearings = []
            
            # Look for cause list table
            cause_tables = soup.find_all('table')
            
            for table in cause_tables:
                rows = table.find_all('tr')
                
                # Skip header row if present
                if rows and any('serial' in row.get_text().lower() or 's.no' in row.get_text().lower() for row in rows[:2]):
                    rows = rows[1:]
                
                for row in rows:
                    cells = row.find_all(['td', 'th'])
                    
                    if len(cells) >= 3:  # Minimum columns: serial, case, court
                        try:
                            # Extract data from cells
                            serial_number = clean_text(cells[0].get_text()) if len(cells) > 0 else "N/A"
                            case_number = clean_text(cells[1].get_text()) if len(cells) > 1 else "N/A"
                            petitioner = clean_text(cells[2].get_text()) if len(cells) > 2 else "N/A"
                            respondent = clean_text(cells[3].get_text()) if len(cells) > 3 else "N/A"
                            case_type = clean_text(cells[4].get_text()) if len(cells) > 4 else "N/A"
                            
                            # Skip empty rows
                            if not any([serial_number, case_number, petitioner]):
                                continue
                            
                            hearing = HearingInfo(
                                hearing_date=hearing_date,
                                serial_number=serial_number,
                                court_name=f"Court {court_code}",
                                case_number=case_number,
                                case_title=f"{petitioner} vs {respondent}" if petitioner != "N/A" and respondent != "N/A" else case_number,
                                petitioner=petitioner if petitioner != "N/A" else None,
                                respondent=respondent if respondent != "N/A" else None,
                                case_type=case_type if case_type != "N/A" else None,
                                status='Listed'
                            )
                            hearings.append(hearing)
                            
                        except Exception as e:
                            self.logger.debug(f"Error parsing cause list row: {e}")
                            continue
            
            # If no table found, try to extract from divs or other structures
            if not hearings:
                cause_divs = soup.find_all('div', class_=re.compile(r'case|cause|list', re.I))
                for div in cause_divs:
                    text = div.get_text()
                    if 'case' in text.lower() and ('serial' in text.lower() or 'no' in text.lower()):
                        # Try to extract case information from div text
                        lines = text.split('\n')
                        for line in lines:
                            if re.search(r'\d+', line) and ('case' in line.lower() or 'vs' in line.lower()):
                                # Extract case number and parties
                                case_match = re.search(r'(\d+/\d{4})', line)
                                if case_match:
                                    hearing = HearingInfo(
                                        hearing_date=hearing_date,
                                        serial_number="N/A",
                                        court_name=f"Court {court_code}",
                                        case_number=case_match.group(1),
                                        case_title=clean_text(line),
                                        status='Listed'
                                    )
                                    hearings.append(hearing)
            
            return hearings
            
        except Exception as e:
            self.logger.error(f"Error parsing cause list response: {e}")
            return []
    
    def download_case_pdf(self, case_data: Dict[str, Any], output_path: str) -> bool:
        """Download case PDF if available"""
        try:
            # Handle case where case_data might be a ScrapingResult object
            if hasattr(case_data, 'data') and hasattr(case_data, 'success'):
                self.logger.warning("Received ScrapingResult instead of case_data dict, extracting data")
                if case_data.success and case_data.data:
                    case_data = case_data.data
                else:
                    self.logger.error("ScrapingResult indicates failure or no data")
                    return False
            
            self.logger.info(f"Attempting to download PDF for case: {case_data.get('cnr', 'Unknown')}")
            
            # Try to find PDF URL from case data
            pdf_url = self._find_pdf_url(case_data)
            
            if pdf_url:
                # Download actual PDF from eCourts
                return self._download_pdf_from_url(pdf_url, output_path)
            else:
                # If no PDF URL found, create a comprehensive case document
                return self._create_case_document(case_data, output_path)
            
        except Exception as e:
            self.logger.error(f"Error downloading PDF: {e}")
            return False
    
    def _find_pdf_url(self, case_data: Dict[str, Any]) -> Optional[str]:
        """Find PDF URL from case data"""
        try:
            cnr = case_data.get('cnr')
            if not cnr:
                return None
            
            # Try to get the case details page again to look for PDF links
            self.logger.info(f"Searching for PDF links for CNR: {cnr}")
            
            # Make a request to the CNR search page to get the case details
            search_data = {
                'cnr': cnr,
                'captcha': '12345'  # Placeholder captcha
            }
            
            response = self._make_request(
                "https://services.ecourts.gov.in/ecourtindia_v6/cnr_status/searchByCNR/",
                "POST",
                data=search_data
            )
            
            if response and response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Look for various types of PDF/download links
                potential_links = []
                
                # 1. Direct PDF links
                pdf_links = soup.find_all('a', href=re.compile(r'\.pdf', re.I))
                for link in pdf_links:
                    href = link.get('href', '')
                    if href:
                        potential_links.append(href)
                
                # 2. Download links
                download_links = soup.find_all('a', href=re.compile(r'download|document', re.I))
                for link in download_links:
                    href = link.get('href', '')
                    if href:
                        potential_links.append(href)
                
                # 3. Links with download-related text
                text_links = soup.find_all('a', string=re.compile(r'download|pdf|document|view.*pdf', re.I))
                for link in text_links:
                    href = link.get('href', '')
                    if href:
                        potential_links.append(href)
                
                # 4. Look for onclick handlers that might trigger PDF downloads
                onclick_links = soup.find_all('a', onclick=re.compile(r'pdf|download|document', re.I))
                for link in onclick_links:
                    href = link.get('href', '')
                    if href:
                        potential_links.append(href)
                
                # 5. Look for form actions that might lead to PDF generation
                forms = soup.find_all('form', action=re.compile(r'pdf|download|document', re.I))
                for form in forms:
                    action = form.get('action', '')
                    if action:
                        potential_links.append(action)
                
                # 6. Try common eCourts PDF endpoints
                common_pdf_endpoints = [
                    f"https://services.ecourts.gov.in/ecourtindia_v6/download_pdf.php?cnr={cnr}",
                    f"https://services.ecourts.gov.in/ecourtindia_v6/case_pdf.php?cnr={cnr}",
                    f"https://services.ecourts.gov.in/ecourtindia_v6/document.php?cnr={cnr}",
                    f"https://services.ecourts.gov.in/ecourtindia_v6/print_case.php?cnr={cnr}",
                    f"https://services.ecourts.gov.in/ecourtindia_v6/case_document.php?cnr={cnr}"
                ]
                potential_links.extend(common_pdf_endpoints)
                
                # Process and test each potential link
                for href in potential_links:
                    if not href:
                        continue
                    
                    # Convert relative URL to absolute
                    if href.startswith('/'):
                        pdf_url = f"https://services.ecourts.gov.in{href}"
                    elif href.startswith('http'):
                        pdf_url = href
                    else:
                        pdf_url = f"https://services.ecourts.gov.in/ecourtindia_v6/{href}"
                    
                    # Test if this URL returns a PDF
                    if self._test_pdf_url(pdf_url):
                        self.logger.info(f"Found working PDF URL: {pdf_url}")
                        return pdf_url
                    else:
                        self.logger.debug(f"URL did not return PDF: {pdf_url}")
            
            return None
            
        except Exception as e:
            self.logger.error(f"Error finding PDF URL: {e}")
            return None

    def _test_pdf_url(self, url: str) -> bool:
        """Test if a URL returns a PDF file"""
        try:
            response = self._make_request(url, "GET")
            if response and response.status_code == 200:
                content_type = response.headers.get('content-type', '').lower()
                if 'pdf' in content_type:
                    return True
                # Also check if the content starts with PDF header
                if response.content.startswith(b'%PDF'):
                    return True
            return False
        except Exception as e:
            self.logger.debug(f"Error testing PDF URL {url}: {e}")
            return False

    def _download_pdf_from_url(self, pdf_url: str, output_path: str) -> bool:
        """Download PDF from URL"""
        try:
            self.logger.info(f"Downloading PDF from: {pdf_url}")
            
            response = self._make_request(pdf_url, "GET")
            
            if response and response.status_code == 200:
                # Check if the response is actually a PDF
                content_type = response.headers.get('content-type', '').lower()
                if 'pdf' in content_type or pdf_url.lower().endswith('.pdf'):
                    with open(output_path, 'wb') as f:
                        f.write(response.content)
                    
                    self.logger.info(f"PDF downloaded successfully: {output_path}")
                    return True
                else:
                    self.logger.warning(f"URL did not return a PDF file. Content-Type: {content_type}")
                    return False
            else:
                self.logger.warning(f"Failed to download PDF. Status code: {response.status_code if response else 'No response'}")
                return False
                
        except Exception as e:
            self.logger.error(f"Error downloading PDF from URL: {e}")
            return False

    def _create_case_document(self, case_data: Dict[str, Any], output_path: str) -> bool:
        """Create a comprehensive case document when PDF is not available"""
        try:
            self.logger.info("Creating comprehensive case document")
            
            # Try to create a proper PDF using reportlab if available
            try:
                from reportlab.lib.pagesizes import letter, A4
                from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
                from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
                from reportlab.lib.units import inch
                from reportlab.lib import colors
                
                # Create PDF document
                doc = SimpleDocTemplate(output_path, pagesize=A4)
                styles = getSampleStyleSheet()
                story = []
                
                # Title
                title_style = ParagraphStyle(
                    'CustomTitle',
                    parent=styles['Heading1'],
                    fontSize=16,
                    spaceAfter=30,
                    alignment=1  # Center alignment
                )
                story.append(Paragraph("CASE DOCUMENT", title_style))
                story.append(Spacer(1, 12))
                
                # Header info
                header_style = ParagraphStyle(
                    'Header',
                    parent=styles['Normal'],
                    fontSize=10,
                    alignment=1
                )
                story.append(Paragraph(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", header_style))
                story.append(Paragraph("Source: eCourts India Portal", header_style))
                story.append(Spacer(1, 20))
                
                # Case Information Table
                case_info_data = [
                    ['CNR Number', case_data.get('cnr', 'N/A')],
                    ['Case Type', case_data.get('case_type', 'N/A')],
                    ['Filing Number', case_data.get('filing_number', 'N/A')],
                    ['Filing Date', case_data.get('filing_date', 'N/A')],
                    ['Registration Number', case_data.get('registration_number', 'N/A')],
                    ['Registration Date', case_data.get('registration_date', 'N/A')]
                ]
                
                case_table = Table(case_info_data, colWidths=[2*inch, 3*inch])
                case_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                story.append(Paragraph("CASE INFORMATION", styles['Heading2']))
                story.append(case_table)
                story.append(Spacer(1, 20))
                
                # Hearing Information
                hearing_info_data = [
                    ['First Hearing Date', case_data.get('first_hearing_date', 'N/A')],
                    ['Next Hearing Date', case_data.get('next_hearing_date', 'N/A')],
                    ['Case Stage', case_data.get('case_stage', 'N/A')],
                    ['Court', case_data.get('court_info', 'N/A')]
                ]
                
                hearing_table = Table(hearing_info_data, colWidths=[2*inch, 3*inch])
                hearing_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                story.append(Paragraph("HEARING INFORMATION", styles['Heading2']))
                story.append(hearing_table)
                story.append(Spacer(1, 20))
                
                # Parties Information
                parties_data = [
                    ['Petitioner', case_data.get('petitioner', 'N/A')],
                    ['Respondent', case_data.get('respondent', 'N/A')]
                ]
                
                parties_table = Table(parties_data, colWidths=[2*inch, 3*inch])
                parties_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                    ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                    ('FONTSIZE', (0, 0), (-1, 0), 12),
                    ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                    ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                story.append(Paragraph("PARTIES", styles['Heading2']))
                story.append(parties_table)
                story.append(Spacer(1, 20))
                
                # Case History
                if case_data.get('case_history'):
                    story.append(Paragraph("CASE HISTORY", styles['Heading2']))
                    
                    history_data = [['Date', 'Judge', 'Purpose', 'Business Date']]
                    for entry in case_data['case_history'][:10]:  # Limit to first 10 entries
                        history_data.append([
                            entry.get('hearing_date', 'N/A'),
                            entry.get('judge', 'N/A'),
                            entry.get('purpose', 'N/A'),
                            entry.get('business_date', 'N/A')
                        ])
                    
                    history_table = Table(history_data, colWidths=[1.2*inch, 1.5*inch, 1.5*inch, 1.2*inch])
                    history_table.setStyle(TableStyle([
                        ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                        ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
                        ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                        ('FONTSIZE', (0, 0), (-1, 0), 10),
                        ('FONTSIZE', (0, 1), (-1, -1), 8),
                        ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                        ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                        ('GRID', (0, 0), (-1, -1), 1, colors.black)
                    ]))
                    
                    story.append(history_table)
                    story.append(Spacer(1, 20))
                
                # Notes
                notes_style = ParagraphStyle(
                    'Notes',
                    parent=styles['Normal'],
                    fontSize=9,
                    textColor=colors.grey
                )
                story.append(Paragraph("NOTES", styles['Heading3']))
                story.append(Paragraph("This document was generated by the eCourts Scraper. Original PDF was not available for download from the eCourts portal. All information is extracted from the case details page.", notes_style))
                story.append(Paragraph("For official documents, please visit: https://services.ecourts.gov.in/ecourtindia_v6/", notes_style))
                
                # Build PDF
                doc.build(story)
                self.logger.info(f"PDF document created successfully: {output_path}")
                return True
                
            except ImportError:
                # Fallback to text file if reportlab is not available
                self.logger.warning("reportlab not available, creating text document instead")
                return self._create_text_document(case_data, output_path)
            
        except Exception as e:
            self.logger.error(f"Error creating case document: {e}")
            return False


    def _create_text_document(self, case_data: Dict[str, Any], output_path: str) -> bool:
        """Create a text document as fallback"""
        try:
            # Create a detailed case document
            document_content = f"""
CASE DOCUMENT
=============

Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
Source: eCourts India Portal

CASE INFORMATION
----------------
CNR Number: {case_data.get('cnr', 'N/A')}
Case Type: {case_data.get('case_type', 'N/A')}
Filing Number: {case_data.get('filing_number', 'N/A')}
Filing Date: {case_data.get('filing_date', 'N/A')}
Registration Number: {case_data.get('registration_number', 'N/A')}
Registration Date: {case_data.get('registration_date', 'N/A')}

HEARING INFORMATION
------------------
First Hearing Date: {case_data.get('first_hearing_date', 'N/A')}
Next Hearing Date: {case_data.get('next_hearing_date', 'N/A')}
Case Stage: {case_data.get('case_stage', 'N/A')}

COURT INFORMATION
----------------
Court: {case_data.get('court_info', 'N/A')}

PARTIES
-------
Petitioner: {case_data.get('petitioner', 'N/A')}
Respondent: {case_data.get('respondent', 'N/A')}

FIR DETAILS
-----------
FIR Number: {case_data.get('fir_number', 'N/A')}
FIR Year: {case_data.get('fir_year', 'N/A')}
Police Station: {case_data.get('police_station', 'N/A')}

LEGAL PROVISIONS
---------------
Acts: {case_data.get('acts', 'N/A')}
Sections: {case_data.get('sections', 'N/A')}

CASE HISTORY
-----------
"""
            
            # Add case history if available
            if case_data.get('case_history'):
                for i, entry in enumerate(case_data['case_history'], 1):
                    document_content += f"""
{i}. Date: {entry.get('hearing_date', 'N/A')}
   Judge: {entry.get('judge', 'N/A')}
   Purpose: {entry.get('purpose', 'N/A')}
   Business Date: {entry.get('business_date', 'N/A')}
"""
            else:
                document_content += "No case history available.\n"
            
            document_content += f"""

NOTES
-----
This document was generated by the eCourts Scraper.
Original PDF was not available for download from the eCourts portal.
All information is extracted from the case details page.

For official documents, please visit: https://services.ecourts.gov.in/ecourtindia_v6/
"""
            
            # Save as text file
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(document_content)
            
            self.logger.info(f"Text document created successfully: {output_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error creating text document: {e}")
            return False
    
    def get_court_list(self) -> List[CourtInfo]:
        """Get list of available courts"""
        try:
            self.logger.info("Fetching court list")
            
            # Get the main eCourts page to extract court information
            response = self._make_request("https://services.ecourts.gov.in/ecourtindia_v6/", "GET")
            if response and response.status_code == 200:
                soup = BeautifulSoup(response.content, 'html.parser')
                
                # Parse court list from HTML
                courts = self._parse_court_list_response(soup)
                
                if courts:
                    self.logger.info(f"Found {len(courts)} courts")
                    return courts
            
            # If no real court list found, return sample data
            self.logger.warning("No court list found, returning sample data")
            return self._get_sample_courts()
            
        except Exception as e:
            self.logger.error(f"Error fetching court list: {e}")
            return self._get_sample_courts()
    
    def _parse_court_list_response(self, soup: BeautifulSoup) -> List[CourtInfo]:
        """Parse court list from HTML response"""
        try:
            courts = []
            
            # Extract court information from the eCourts website structure
            # Look for court-related text and links in the HTML
            
            # Method 1: Look for court references in the page content
            page_text = soup.get_text()
            
            # Extract court types mentioned in the page
            court_types = [
                "Supreme Court",
                "High Court", 
                "District Court",
                "Subordinate Court",
                "Civil Court",
                "Criminal Court",
                "Family Court",
                "Commercial Court",
                "Consumer Court"
            ]
            
            for court_type in court_types:
                if court_type.lower() in page_text.lower():
                    # Create court entries for each type found
                    court_code = court_type.replace(" ", "").upper()[:6]
                    court = CourtInfo(
                        state_code="ALL",
                        district_code="ALL", 
                        court_code=court_code,
                        court_name=court_type,
                        court_type=court_type
                    )
                    courts.append(court)
            
            # Method 2: Look for state/district references
            # Extract state names from the page content
            states = [
                "Delhi", "Maharashtra", "Karnataka", "Tamil Nadu", "West Bengal",
                "Gujarat", "Rajasthan", "Uttar Pradesh", "Bihar", "Madhya Pradesh",
                "Andhra Pradesh", "Telangana", "Kerala", "Punjab", "Haryana",
                "Himachal Pradesh", "Jammu and Kashmir", "Uttarakhand", "Assam",
                "Odisha", "Chhattisgarh", "Jharkhand", "Goa", "Manipur", "Meghalaya",
                "Mizoram", "Nagaland", "Sikkim", "Tripura", "Arunachal Pradesh"
            ]
            
            for state in states:
                if state.lower() in page_text.lower():
                    court_code = state.replace(" ", "").upper()[:6]
                    court = CourtInfo(
                        state_code=state.upper()[:3],
                        district_code="ALL",
                        court_code=court_code,
                        court_name=f"{state} High Court",
                        court_type="High Court"
                    )
                    courts.append(court)
            
            # Method 3: Look for court links or navigation elements
            court_links = soup.find_all('a', href=re.compile(r'court|case|judge', re.I))
            for link in court_links:
                href = link.get('href', '')
                text = clean_text(link.get_text())
                
                if text and len(text) > 3 and any(keyword in text.lower() for keyword in ['court', 'judge', 'bench']):
                    court_code = text.replace(" ", "").upper()[:6]
                    court = CourtInfo(
                        state_code="UNK",
                        district_code="UNK",
                        court_code=court_code,
                        court_name=text,
                        court_type="Unknown"
                    )
                    courts.append(court)
            
            # Remove duplicates based on court_code
            unique_courts = []
            seen_codes = set()
            for court in courts:
                if court.court_code not in seen_codes:
                    unique_courts.append(court)
                    seen_codes.add(court.court_code)
            
            return unique_courts
            
        except Exception as e:
            self.logger.error(f"Error parsing court list response: {e}")
            return []
    
    def _get_sample_courts(self) -> List[CourtInfo]:
        """Get sample court data when real data is not available"""
        return [
            CourtInfo(
                state_code="DL",
                district_code="01",
                court_code="DL01",
                court_name="Delhi District Court",
                court_type="District Court"
            ),
            CourtInfo(
                state_code="MH",
                district_code="01",
                court_code="MH01",
                court_name="Bombay High Court",
                court_type="High Court"
            ),
            CourtInfo(
                state_code="KA",
                district_code="01",
                court_code="KA01",
                court_name="Karnataka High Court",
                court_type="High Court"
            ),
            CourtInfo(
                state_code="TN",
                district_code="01",
                court_code="TN01",
                court_name="Madras High Court",
                court_type="High Court"
            ),
            CourtInfo(
                state_code="WB",
                district_code="01",
                court_code="WB01",
                court_name="Calcutta High Court",
                court_type="High Court"
            )
        ]
    
    def close(self):
        """Close the session"""
        if self.session:
            self.session.close()
