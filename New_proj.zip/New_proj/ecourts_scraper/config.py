"""
Configuration settings for eCourts Scraper
"""

import os
from typing import Dict, Any


class Config:
    """Base configuration class"""
    
    # Base URLs
    ECOURTS_BASE_URL = "https://services.ecourts.gov.in/ecourtindia_v6/"
    
    # Request settings
    DEFAULT_TIMEOUT = int(os.getenv('ECOURTS_TIMEOUT', 30))
    DEFAULT_DELAY = float(os.getenv('ECOURTS_DELAY', 1.0))
    
    # Output settings
    DEFAULT_OUTPUT_DIR = os.getenv('ECOURTS_OUTPUT_DIR', './output')
    
    # User agent for requests
    USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"
    
    # Request headers
    DEFAULT_HEADERS = {
        'User-Agent': USER_AGENT,
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Accept-Language': 'en-US,en;q=0.5',
        'Accept-Encoding': 'gzip, deflate',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    
    # Logging settings
    LOG_LEVEL = os.getenv('ECOURTS_LOG_LEVEL', 'INFO')
    LOG_FILE = 'ecourts_scraper.log'
    
    # Validation settings
    CNR_MIN_LENGTH = 16
    CNR_MAX_LENGTH = 20
    YEAR_MIN = 2000
    YEAR_MAX = 2030
    
    # Date formats
    DATE_FORMATS = [
        '%d-%m-%Y',
        '%d/%m/%Y',
        '%Y-%m-%d',
        '%d-%m-%y',
        '%d/%m/%y'
    ]
    
    # Common court codes (example data)
    SAMPLE_COURTS = [
        {
            'state_code': 'DL',
            'district_code': '01',
            'court_code': '001',
            'court_name': 'District Court Delhi',
            'court_type': 'District Court'
        },
        {
            'state_code': 'MH',
            'district_code': '01',
            'court_code': '002',
            'court_name': 'Bombay High Court',
            'court_type': 'High Court'
        },
        {
            'state_code': 'KA',
            'district_code': '01',
            'court_code': '003',
            'court_name': 'Karnataka High Court',
            'court_type': 'High Court'
        },
        {
            'state_code': 'TN',
            'district_code': '01',
            'court_code': '004',
            'court_name': 'Madras High Court',
            'court_type': 'High Court'
        },
        {
            'state_code': 'WB',
            'district_code': '01',
            'court_code': '005',
            'court_name': 'Calcutta High Court',
            'court_type': 'High Court'
        }
    ]


class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    LOG_LEVEL = 'DEBUG'
    DEFAULT_DELAY = 0.5  # Faster for development


class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    LOG_LEVEL = 'INFO'
    DEFAULT_DELAY = 2.0  # Slower for production


class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    LOG_LEVEL = 'DEBUG'
    DEFAULT_DELAY = 0.1  # Very fast for testing


# Configuration mapping
config_map = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': Config
}


def get_config(config_name: str = None) -> Config:
    """Get configuration class"""
    if config_name is None:
        config_name = os.getenv('ECOURTS_CONFIG', 'default')
    
    return config_map.get(config_name, Config)()
