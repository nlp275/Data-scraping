#!/usr/bin/env python3
"""
eCourts Scraper - Main Entry Point
"""

from ecourts_scraper.cli import cli

if __name__ == '__main__':
    cli()
