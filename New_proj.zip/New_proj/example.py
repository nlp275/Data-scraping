#!/usr/bin/env python3
"""
Example usage of eCourts Scraper
"""

from datetime import date
from ecourts_scraper.scraper import ECourtsScraper
from ecourts_scraper.utils import save_to_json, format_output


def example_case_search():
    """Example: Search for a case by CNR"""
    print("=== Example: Case Search by CNR ===")
    
    # Initialize scraper
    scraper = ECourtsScraper()
    
    try:
        # Search by CNR (example - replace with actual CNR)
        cnr = "12345678901234567890"  # Replace with actual CNR
        
        result = scraper.search_case_by_cnr(cnr)
        
        if result.success:
            print("✓ Case found successfully!")
            print(f"Case data: {result.data}")
            
            # Check for today and tomorrow
            today = date.today()
            tomorrow = today.replace(day=today.day + 1)
            
            hearings = scraper.get_case_hearings(result.data, [today, tomorrow])
            
            if hearings:
                print(f"\nFound {len(hearings)} hearing(s):")
                for hearing in hearings:
                    print(f"  - Date: {hearing.hearing_date}")
                    print(f"    Serial: {hearing.serial_number}")
                    print(f"    Court: {hearing.court_name}")
            else:
                print("\nNo hearings found for today or tomorrow.")
        else:
            print(f"✗ Error: {result.message}")
    
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        scraper.close()


def example_case_search_by_details():
    """Example: Search for a case by details"""
    print("\n=== Example: Case Search by Details ===")
    
    # Initialize scraper
    scraper = ECourtsScraper()
    
    try:
        # Search by case details
        case_type = "ABC"
        case_number = "123"
        year = "2023"
        
        result = scraper.search_case_by_details(
            case_type=case_type,
            case_number=case_number,
            year=year,
            state_code="DL",  # Delhi
            district_code="01",
            court_code="001"
        )
        
        if result.success:
            print("✓ Case found successfully!")
            print(f"Case data: {result.data}")
            
            # Check for today
            today = date.today()
            hearings = scraper.get_case_hearings(result.data, [today])
            
            if hearings:
                print(f"\nFound {len(hearings)} hearing(s) for today:")
                for hearing in hearings:
                    print(f"  - Serial: {hearing.serial_number}")
                    print(f"    Court: {hearing.court_name}")
            else:
                print("\nNo hearings found for today.")
        else:
            print(f"✗ Error: {result.message}")
    
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        scraper.close()


def example_cause_list():
    """Example: Download cause list"""
    print("\n=== Example: Download Cause List ===")
    
    # Initialize scraper
    scraper = ECourtsScraper()
    
    try:
        # Get cause list for a court
        court_code = "001"
        today = date.today()
        
        cause_list = scraper.get_cause_list(court_code, today)
        
        if cause_list:
            print(f"✓ Cause list downloaded successfully!")
            print(f"Court: {cause_list.court_name}")
            print(f"Date: {cause_list.hearing_date}")
            print(f"Total cases: {cause_list.total_cases}")
            
            # Show first few cases
            if cause_list.hearings:
                print("\nFirst 5 cases:")
                for i, hearing in enumerate(cause_list.hearings[:5]):
                    print(f"  {i+1}. {hearing.serial_number} - {hearing.case_number}")
            
            # Save to file
            output_data = cause_list.dict()
            if save_to_json(output_data, "cause_list_example.json"):
                print("\n✓ Cause list saved to cause_list_example.json")
        else:
            print("✗ No cause list found")
    
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        scraper.close()


def example_pdf_download():
    """Example: Download case PDF"""
    print("\n=== Example: Download Case PDF ===")
    
    # Initialize scraper
    scraper = ECourtsScraper()
    
    try:
        # Example case data
        case_data = {
            'cnr': '12345678901234567890',
            'case_number': '123/2023',
            'case_type': 'ABC'
        }
        
        # Try to download PDF
        success = scraper.download_case_pdf(case_data, "case_example.pdf")
        
        if success:
            print("✓ PDF downloaded successfully to case_example.pdf")
        else:
            print("✗ No PDF available for this case")
    
    except Exception as e:
        print(f"Error: {e}")
    
    finally:
        scraper.close()


def main():
    """Run all examples"""
    print("eCourts Scraper Examples")
    print("=" * 50)
    
    # Note: These examples use placeholder data
    # In real usage, you would need actual CNR numbers and case details
    
    print("\nNote: These examples use placeholder data.")
    print("For real usage, replace with actual CNR numbers and case details.\n")
    
    # Run examples
    example_case_search()
    example_case_search_by_details()
    example_cause_list()
    example_pdf_download()
    
    print("\n" + "=" * 50)
    print("Examples completed!")
    print("\nFor interactive usage, run:")
    print("  python main.py --help")
    print("\nFor web interface, run:")
    print("  python main.py web")


if __name__ == '__main__':
    main()
