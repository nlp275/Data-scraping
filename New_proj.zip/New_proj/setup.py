"""
Setup script for eCourts Scraper
"""

from setuptools import setup, find_packages
import os

# Read the contents of README file
this_directory = os.path.abspath(os.path.dirname(__file__))
with open(os.path.join(this_directory, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

# Read requirements
with open('requirements.txt') as f:
    requirements = f.read().splitlines()

setup(
    name="ecourts-scraper",
    version="1.0.0",
    author="eCourts Scraper Team",
    author_email="contact@example.com",
    description="A Python tool to fetch court listings from eCourts India",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/yourusername/ecourts-scraper",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Intended Audience :: Legal Industry",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Topic :: Internet :: WWW/HTTP :: Indexing/Search",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Text Processing :: Markup :: HTML",
    ],
    python_requires=">=3.7",
    install_requires=requirements,
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.0",
            "black>=21.0",
            "flake8>=3.8",
            "mypy>=0.800",
        ],
        "web": [
            "flask>=2.3.0",
        ],
    },
    entry_points={
        "console_scripts": [
            "ecourts-scraper=ecourts_scraper.cli:cli",
        ],
    },
    include_package_data=True,
    zip_safe=False,
    keywords="ecourts, scraper, court, legal, india, case, hearing, cause-list",
    project_urls={
        "Bug Reports": "https://github.com/yourusername/ecourts-scraper/issues",
        "Source": "https://github.com/yourusername/ecourts-scraper",
        "Documentation": "https://github.com/yourusername/ecourts-scraper#readme",
    },
)
