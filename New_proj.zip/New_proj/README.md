# eCourts Scraper

A Python tool to fetch court listings from [eCourts India](https://services.ecourts.gov.in/ecourtindia_v6/).


[## Installation

### Prerequisites

- Python 3.7 or higher
- pip package manager]

### Setup

1. **Clone or download the project:**
   ```bash
   git clone <repository-url>
   cd ecourts-scraper
   ```

2. **Install dependencies:**
   ```bash
   pip3 install -r requirements.txt
   ```

3. **Run the web app:**
   ```bash
   python3 main.py web --host 127.0.0.1 --port 5000
   ```

4. **Open in browser:**
   ```bash
   sleep 3 && open "http://127.0.0.1:5000"
  (or You can also manually open your browser and visit http://127.0.0.1:5000.)
   ```


#### Basic Case Search

**Search by CNR:**
```bash
python main.py search --cnr "12345678901234567890" --date today
```

#### Cause List Download

**Get cause list for today:**
```bash
python main.py causelist --court-code "001" --date today
```

#### project structure

ecourts_scraper/
 ├── scraper.py      # Core scraping logic
 ├── web_api.py      # Web interface logic
 ├── cli.py          # CLI support
 ├── config.py       # Configurations
 ├── utils.py        # Helper utilities
 └── models.py       # Data models




## Features

✅ **Case Search**
- Search by CNR (Case Registration Number)
- Search by Case Type, Number, and Year
- Check if cases are listed today or tomorrow
- Display serial number and court name

✅ **Cause List Download**
- Download entire cause list for any court and date
- Save as JSON or text format

✅ **PDF Download**
- Download case PDFs when available

✅ **Multiple Interfaces**
- Command Line Interface (CLI)
- Web API interface
- Python library

✅ **Output Formats**
- Console display
- JSON files
- Text files
- PDF files

