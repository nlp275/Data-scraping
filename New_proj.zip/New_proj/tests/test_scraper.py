"""
Tests for eCourts Scraper
"""

import pytest
from datetime import date, datetime
from ecourts_scraper.scraper import ECourtsScraper
from ecourts_scraper.models import CaseInfo, HearingInfo, CauseList
from ecourts_scraper.utils import validate_cnr, validate_case_input, get_date_range


class TestUtils:
    """Test utility functions"""
    
    def test_validate_cnr_valid(self):
        """Test valid CNR validation"""
        assert validate_cnr("12345678901234567890") == True
        assert validate_cnr("1234567890123456") == True
        assert validate_cnr("123456789012345678901") == True
    
    def test_validate_cnr_invalid(self):
        """Test invalid CNR validation"""
        assert validate_cnr("") == False
        assert validate_cnr("12345") == False
        assert validate_cnr("abc123def456") == False
        assert validate_cnr("123456789012345678901234567890") == False
    
    def test_validate_case_input_valid(self):
        """Test valid case input validation"""
        assert validate_case_input("ABC", "123", "2023") == True
        assert validate_case_input("XYZ", "456", "2020") == True
    
    def test_validate_case_input_invalid(self):
        """Test invalid case input validation"""
        assert validate_case_input("", "123", "2023") == False
        assert validate_case_input("ABC", "", "2023") == False
        assert validate_case_input("ABC", "123", "") == False
        assert validate_case_input("ABC", "123", "1999") == False  # Too old
        assert validate_case_input("ABC", "123", "2030") == False  # Too future
    
    def test_get_date_range(self):
        """Test date range functionality"""
        # Test today
        start, end = get_date_range("today")
        assert start == date.today()
        assert end == date.today()
        
        # Test tomorrow
        start, end = get_date_range("tomorrow")
        tomorrow = date.today().replace(day=date.today().day + 1)
        assert start == tomorrow
        assert end == tomorrow
        
        # Test both
        start, end = get_date_range("both")
        assert start == date.today()
        assert end == date.today().replace(day=date.today().day + 1)


class TestModels:
    """Test data models"""
    
    def test_case_info_model(self):
        """Test CaseInfo model"""
        case = CaseInfo(
            cnr="12345678901234567890",
            case_type="ABC",
            case_number="123/2023",
            petitioner="John Doe",
            respondent="Jane Smith"
        )
        
        assert case.cnr == "12345678901234567890"
        assert case.case_type == "ABC"
        assert case.case_number == "123/2023"
        assert case.petitioner == "John Doe"
        assert case.respondent == "Jane Smith"
    
    def test_hearing_info_model(self):
        """Test HearingInfo model"""
        hearing = HearingInfo(
            hearing_date=date.today(),
            serial_number="001",
            court_name="District Court Delhi",
            case_number="123/2023"
        )
        
        assert hearing.hearing_date == date.today()
        assert hearing.serial_number == "001"
        assert hearing.court_name == "District Court Delhi"
        assert hearing.case_number == "123/2023"


class TestScraper:
    """Test scraper functionality"""
    
    def test_scraper_initialization(self):
        """Test scraper initialization"""
        scraper = ECourtsScraper()
        assert scraper.timeout == 30
        assert scraper.delay == 1.0
        assert scraper.base_url == "https://services.ecourts.gov.in/ecourtindia_v6/"
        scraper.close()
    
    def test_scraper_initialization_custom_params(self):
        """Test scraper initialization with custom parameters"""
        scraper = ECourtsScraper(timeout=60, delay=2.0)
        assert scraper.timeout == 60
        assert scraper.delay == 2.0
        scraper.close()
    
    def test_search_case_by_cnr_mock(self):
        """Test case search by CNR (mock test)"""
        scraper = ECourtsScraper()
        
        # This would normally make a real request
        # For testing, we'll just verify the method exists and can be called
        try:
            result = scraper.search_case_by_cnr("12345678901234567890")
            # The actual result will depend on the real eCourts response
            assert hasattr(result, 'success')
            assert hasattr(result, 'message')
            assert hasattr(result, 'data')
        except Exception:
            # Expected for mock test without real network access
            pass
        finally:
            scraper.close()
    
    def test_search_case_by_details_mock(self):
        """Test case search by details (mock test)"""
        scraper = ECourtsScraper()
        
        try:
            result = scraper.search_case_by_details(
                case_type="ABC",
                case_number="123",
                year="2023"
            )
            assert hasattr(result, 'success')
            assert hasattr(result, 'message')
            assert hasattr(result, 'data')
        except Exception:
            # Expected for mock test without real network access
            pass
        finally:
            scraper.close()


# Integration tests (require network access)
@pytest.mark.integration
class TestIntegration:
    """Integration tests that require network access"""
    
    def test_real_case_search(self):
        """Test real case search (requires network)"""
        scraper = ECourtsScraper()
        
        try:
            # Use a known test CNR if available
            result = scraper.search_case_by_cnr("12345678901234567890")
            assert result is not None
        except Exception as e:
            # This is expected if the test CNR doesn't exist
            print(f"Integration test failed (expected): {e}")
        finally:
            scraper.close()


if __name__ == "__main__":
    pytest.main([__file__])
